export interface AclData {
    [key: string]: {
        canAccess: string[];
        canEdit: string[];
    };
}
export interface QueryAclResponse<T = AclData> {
    data: T;
}
export declare function queryAcl<T = AclData>(roomId: string, key?: string, path?: string, botUrl?: string): Promise<QueryAclResponse<T>>;
