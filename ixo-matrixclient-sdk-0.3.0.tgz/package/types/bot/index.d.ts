import * as _1 from './acl/v1beta1';
import * as _2 from './state/v1beta1';
export declare function createMatrixBotClient(botUrl: string): {
    acl: {
        v1beta1: {
            queryAcl: (roomId: string, key?: string, path?: string, overrideBotUrl?: string) => Promise<_1.QueryAclResponse<_1.AclData>>;
        };
    };
    state: {
        v1beta1: {
            queryState: (roomId: string, key?: string, path?: string, overrideBotUrl?: string) => Promise<_2.QueryStateResponse<unknown>>;
        };
    };
};
