export interface QueryStateResponse<T = unknown> {
    data: T;
}
export declare function queryState<T = unknown>(roomId: string, key?: string, path?: string, botUrl?: string): Promise<QueryStateResponse<T>>;
