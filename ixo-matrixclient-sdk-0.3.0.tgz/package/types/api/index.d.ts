import { UploadContentType } from './media/v1beta1';
import * as _1 from './media/v1beta1';
import * as _2 from './profile/v1beta1';
import * as _3 from './room/v1beta1';
import * as _5 from './event/v1beta1';
export declare function createMatrixApiClient({ homeServerUrl, accessToken }: {
    homeServerUrl: string;
    accessToken?: string;
}): {
    media: {
        v1beta1: {
            upload: (filename: string, type: UploadContentType, file: any, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_1.UploadResponse>;
        };
    };
    profile: {
        v1beta1: {
            queryProfile: (userId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_2.Profile>;
            queryDisplayname: (userId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<string>;
            queryAvatarUrl: (userId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<string>;
            setDisplayname: (userId: string, displayname: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<string>;
            setAvatarUrl: (userId: string, avatarUrl: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<string>;
        };
    };
    account: {
        v1beta1: {
            queryWhoAmI: (overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<string>;
        };
    };
    room: {
        v1beta1: {
            queryId: (alias: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.RoomDirectory>;
            queryVisibility: (roomId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.RoomVisibility>;
            setVisibility: (roomId: string, visibility: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.SetRoomVisibilityResponse>;
            knock: (roomIdOrAlias: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.KnockResponse>;
            join: (roomId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.JoinResponse>;
            listJoinedRooms: (overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.ListJoinedRoomsResponse>;
            listJoinedMembers: (roomId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.ListJoinedMembersResponse>;
            leave: (roomId: string, reason: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.LeaveResponse>;
            kick: (roomId: string, userId: string, reason: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_3.KickResponse>;
        };
    };
    event: {
        v1beta1: {
            queryEvent: (roomId: string, eventId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_5.EventData>;
            queryChildEvents: (roomId: string, parentEventId: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_5.ChildEventsResponse>;
            queryChildEventsByRelType: (roomId: string, parentEventId: string, relType: _5.RelType, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_5.ChildEventsResponse>;
            queryChildEventsByRelTypeAndEventType: (roomId: string, parentEventId: string, relType: _5.RelType, eventType: string, overrideHomeServerUrl?: string, overrideAccessToken?: string) => Promise<_5.ChildEventsResponse>;
        };
    };
};
