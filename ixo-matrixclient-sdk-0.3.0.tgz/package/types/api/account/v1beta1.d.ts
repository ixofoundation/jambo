export declare function queryWhoAmI(homeServerUrl: string, accessToken: string): Promise<string>;
