export interface Profile {
    displayname: string;
    avatar_url: string;
}
export declare function queryProfile(userId: string, homeServerUrl: string, accessToken?: string): Promise<Profile>;
export declare function queryDisplayname(userId: string, homeServerUrl: string, accessToken?: string): Promise<string>;
export declare function queryAvatarUrl(userId: string, homeServerUrl: string, accessToken?: string): Promise<string>;
export declare function setDisplayname(userId: string, displayname: string, homeServerUrl: string, accessToken: string): Promise<string>;
export declare function setAvatarUrl(userId: string, avatarUrl: string, homeServerUrl: string, accessToken: string): Promise<string>;
