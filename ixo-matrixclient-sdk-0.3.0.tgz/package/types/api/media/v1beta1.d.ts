export interface UploadResponse {
    content_uri: string;
}
export declare enum UploadContentType {
    PDF = "application/pdf",
    JPEG = "image/jpeg",
    PNG = "image/png",
    GIF = "image/gif",
    BMP = "image/bmp",
    SVG = "image/svg+xml",
    TIFF = "image/tiff",
    WEBP = "image/webp",
    PLAIN_TEXT = "text/plain",
    CSV = "text/csv",
    HTML = "text/html",
    ZIP = "application/zip",
    GZIP = "application/gzip",
    MULTIPART_FORM_DATA = "multipart/form-data"
}
export declare function upload(filename: string, type: string, file: any, homeServerUrl: string, accessToken?: string): Promise<UploadResponse>;
