export interface RoomDirectory {
    room_id: string;
    servers: string[];
}
export interface RoomVisibility {
    visibility: string;
}
export interface SetRoomVisibilityResponse {
}
export interface KnockResponse {
    room_id: string;
}
export interface JoinResponse {
    room_id: string;
}
export interface ListJoinedRoomsResponse {
    joined_rooms: string[];
}
export interface ListJoinedMembersResponse {
    joined: {
        [userId: string]: {
            avatar_url: string;
            display_name: string;
        };
    };
}
export interface LeaveResponse {
}
export interface KickResponse {
}
export declare function queryId(alias: string, homeServerUrl: string, accessToken?: string): Promise<RoomDirectory>;
export declare function queryVisibility(roomId: string, homeServerUrl?: string, accessToken?: string): Promise<RoomVisibility>;
export declare function setVisibility(roomId: string, visibility: string, homeServerUrl: string, accessToken: string): Promise<SetRoomVisibilityResponse>;
export declare function knock(roomIdOrAlias: string, homeServerUrl: string, accessToken: string): Promise<KnockResponse>;
export declare function join(roomIdOrAlias: string, homeServerUrl: string, accessToken: string): Promise<JoinResponse>;
export declare function listJoinedRooms(homeServerUrl: string, accessToken: string): Promise<ListJoinedRoomsResponse>;
export declare function listJoinedMembers(roomId: string, homeServerUrl: string, accessToken: string): Promise<ListJoinedMembersResponse>;
export declare function leave(roomId: string, reason: string, homeServerUrl: string, accessToken: string): Promise<LeaveResponse>;
export declare function kick(roomId: string, userId: string, reason: string, homeServerUrl: string, accessToken: string): Promise<KickResponse>;
