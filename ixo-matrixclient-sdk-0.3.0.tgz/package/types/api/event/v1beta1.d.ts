export type RelType = 'm.thread' | 'm.in_reply_to' | 'm.annotation' | 'm.replace' | 'm.reference';
interface EventContent {
    [key: string]: any;
}
interface UnsignedData {
    age?: number;
    membership?: string;
    prev_content?: {
        [key: string]: any;
    };
    redacted_because?: {
        [key: string]: any;
    };
    transaction_id?: string;
}
export interface EventData {
    content: EventContent;
    event_id: string;
    origin_server_ts: number;
    sender: string;
    state_key?: string;
    type: string;
    unsigned?: UnsignedData;
    room_id: string;
}
export interface ChildEventsResponse {
    next_batch?: string;
    prev_batch?: string;
    recursion_depth?: number;
    chunk: EventData[];
}
export declare function queryEvent(roomId: string, eventId: string, homeServerUrl: string, accessToken: string): Promise<EventData>;
export declare function queryChildEvents(roomId: string, parentEventId: string, homeServerUrl: string, accessToken: string): Promise<ChildEventsResponse>;
export declare function queryChildEventsByRelType(roomId: string, parentEventId: string, relType: RelType, homeServerUrl: string, accessToken: string): Promise<ChildEventsResponse>;
export declare function queryChildEventsByRelTypeAndEventType(roomId: string, parentEventId: string, relType: RelType, eventType: string, homeServerUrl: string, accessToken: string): Promise<ChildEventsResponse>;
export {};
