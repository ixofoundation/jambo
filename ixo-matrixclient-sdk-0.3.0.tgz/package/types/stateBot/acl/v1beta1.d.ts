export interface AclData {
    [key: string]: {
        canAccess: string[];
        canEdit: string[];
    };
}
export interface QueryAclResponse<T = AclData> {
    data: T;
}
export interface SetAclResponse {
    message: string;
}
export declare function queryAcl<T = AclData>(roomId: string, key: string, path: string, botUrl: string, accessToken?: string): Promise<QueryAclResponse<T>>;
export declare function setAcl(roomId: string, key: string, path: string, value: string, botUrl: string, accessToken?: string): Promise<SetAclResponse>;
