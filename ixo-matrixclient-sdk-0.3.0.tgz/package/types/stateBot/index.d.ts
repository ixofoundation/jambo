import * as _1 from './acl/v1beta1';
import * as _2 from './bot/v1beta1';
import * as _3 from './state/v1beta1';
export declare function createMatrixStateBotClient({ botUrl, accessToken }: {
    botUrl: string;
    accessToken?: string;
}): {
    acl: {
        v1beta1: {
            queryAcl: (roomId: string, key?: string, path?: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.QueryAclResponse<_1.AclData>>;
            setAcl: (roomId: string, key: string, path: string, value: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SetAclResponse>;
        };
    };
    bot: {
        v1beta1: {
            invite: (roomId: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_2.InviteResponse>;
        };
    };
    state: {
        v1beta1: {
            queryState: (roomId: string, key?: string, path?: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_3.QueryStateResponse<unknown>>;
            setState: (roomId: string, key: string, path: string, value: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_3.SetStateResponse>;
        };
    };
};
