export interface QueryStateResponse<T = unknown> {
    data: T;
}
export interface SetStateResponse {
    message: string;
}
export declare function queryState<T = unknown>(roomId: string, key: string, path: string, botUrl: string, accessToken?: string): Promise<QueryStateResponse<T>>;
export declare function setState(roomId: string, key: string, path: string, value: string, botUrl: string, accessToken?: string): Promise<SetStateResponse>;
