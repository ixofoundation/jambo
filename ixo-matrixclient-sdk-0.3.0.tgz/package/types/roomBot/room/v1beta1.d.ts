export interface SourceRoomResponse {
    message: string;
    did: string;
    roomId: string;
    roomAlias: string;
}
export declare function sourceRoom(did: string, botUrl: string, accessToken?: string): Promise<SourceRoomResponse>;
export declare function sourceRoomAndJoin(did: string, homeServerUrl: string, botUrl: string, accessToken: string): Promise<SourceRoomResponse>;
export declare function roomInvite(did: string, botUrl: string, accessToken: string): Promise<SourceRoomResponse>;
export declare function roomInviteAndJoin(did: string, homeServerUrl: string, botUrl: string, accessToken: string): Promise<SourceRoomResponse>;
