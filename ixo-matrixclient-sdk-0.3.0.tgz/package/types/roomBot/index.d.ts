import * as _1 from './room/v1beta1';
export declare function createMatrixRoomBotClient({ homeServerUrl, botUrl, accessToken, }: {
    homeServerUrl: string;
    botUrl: string;
    accessToken: string;
}): {
    room: {
        v1beta1: {
            sourceRoom: (did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SourceRoomResponse>;
            sourceRoomAndJoin: (did: string, overrideHomeServerUrl?: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SourceRoomResponse>;
            roomInvite: (did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SourceRoomResponse>;
            roomInviteAndJoin: (did: string, overrideHomeServerUrl?: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SourceRoomResponse>;
        };
    };
};
