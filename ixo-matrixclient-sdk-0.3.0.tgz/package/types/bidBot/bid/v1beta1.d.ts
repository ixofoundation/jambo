interface Bid {
    id: string;
    did: string;
    collectionId: string;
    type: 'bid';
    address: string;
    data: string;
    role: string;
    created: string;
}
export interface QueryBidsResponse {
    data: Array<Bid>;
    nextPageToken?: string;
}
export interface SubmitBidResponse {
    id: string;
}
export interface ApproveBidResponse {
    id: string;
}
export interface RejectBidResponse {
    id: string;
}
export interface QueryDidIsBlockedResponse {
    blocked: boolean;
}
export interface DidBlockResponse {
    blocked: boolean;
}
export interface DidUnblockResponse {
    blocked: boolean;
}
export declare function queryBids(collectionId: string, pagination: {
    nextPageToken?: string;
}, botUrl: string, accessToken: string): Promise<QueryBidsResponse>;
export declare function queryBidsByDid(collectionId: string, did: string, botUrl: string, accessToken: string): Promise<QueryBidsResponse>;
export declare function submitBid(collectionId: string, bid: string, role: string, botUrl: string, accessToken: string): Promise<SubmitBidResponse>;
export declare function approveBid(bidId: string, collectionId: string, did: string, botUrl: string, accessToken: string): Promise<ApproveBidResponse>;
export declare function rejectBid(bidId: string, collectionId: string, did: string, reason: string, botUrl: string, accessToken: string): Promise<RejectBidResponse>;
export declare function queryDidIsBlocked(collectionId: string, did: string, botUrl: string, accessToken: string): Promise<QueryDidIsBlockedResponse>;
export declare function didBlock(collectionId: string, did: string, botUrl: string, accessToken: string): Promise<DidBlockResponse>;
export declare function didUnblock(collectionId: string, did: string, botUrl: string, accessToken: string): Promise<DidUnblockResponse>;
export {};
