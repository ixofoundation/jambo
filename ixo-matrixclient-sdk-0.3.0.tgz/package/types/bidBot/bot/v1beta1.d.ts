export interface InviteResponse {
    message: string;
}
export declare function invite(roomId: string, botUrl: string, accessToken: string): Promise<InviteResponse>;
