import * as _1 from './bid/v1beta1';
import * as _2 from './bot/v1beta1';
export declare function createMatrixBidBotClient({ botUrl, accessToken }: {
    botUrl: string;
    accessToken?: string;
}): {
    bid: {
        v1beta1: {
            queryBids: (collectionId: string, pagination?: {
                nextPageToken?: string;
            }, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.QueryBidsResponse>;
            queryBidsByDid: (collectionId: string, did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.QueryBidsResponse>;
            submitBid: (collectionId: string, did: string, role: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.SubmitBidResponse>;
            approveBid: (bidId: string, collectionId: string, did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.ApproveBidResponse>;
            rejectBid: (bidId: string, collectionId: string, did: string, reason: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.RejectBidResponse>;
            queryDidIsBlocked: (collectionId: string, did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.QueryDidIsBlockedResponse>;
            didBlock: (collectionId: string, did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.DidBlockResponse>;
            didUnblock: (collectionId: string, did: string, overrideBotUrl?: string, overrideAccessToken?: string) => Promise<_1.DidUnblockResponse>;
        };
    };
    bot: {
        v1beta1: {
            invite: (roomId: string) => Promise<_2.InviteResponse>;
        };
    };
};
