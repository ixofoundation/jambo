import * as _1 from './claim/v1beta1';
import * as _2 from './bot/v1beta1';
export declare function createMatrixClaimBotClient({ botUrl, accessToken }: {
    botUrl: string;
    accessToken?: string;
}): {
    claim: {
        v1beta1: {
            queryClaim: (collectionId: string, cid: string) => Promise<_1.QueryClaimResponse>;
            saveClaim: (collectionId: string, claim: string) => Promise<_1.SaveClaimResponse>;
        };
    };
    bot: {
        v1beta1: {
            invite: (roomId: string) => Promise<_2.InviteResponse>;
        };
    };
};
