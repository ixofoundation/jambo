export interface QueryClaimResponse {
    data: any;
}
export interface SaveClaimResponse {
    data: {
        cid: string;
    };
}
export declare function queryClaim(collectionId: string, cid: string, botUrl: string, accessToken: string): Promise<QueryClaimResponse>;
export declare function saveClaim(collectionId: string, claim: string, botUrl: string, accessToken: string): Promise<SaveClaimResponse>;
