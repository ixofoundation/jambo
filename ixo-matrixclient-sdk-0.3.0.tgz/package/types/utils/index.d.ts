import * as _1 from './mxc';
import * as _2 from './validators';
export declare namespace utils {
    const mxc: typeof _1;
    const validators: typeof _2;
}
