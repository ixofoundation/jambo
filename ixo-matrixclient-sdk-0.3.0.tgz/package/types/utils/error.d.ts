import { Response } from 'node-fetch';
export declare function throwResponseError(response: Response): Promise<void>;
