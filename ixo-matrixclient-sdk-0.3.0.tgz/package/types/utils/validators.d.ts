/**
 * Validate if a string is a valid user ID
 * @param userId - The user ID to validate
 * @returns Boolean to indicate if the user ID is valid
 */
export declare function isValidUserId(userId: string): boolean;
/**
 * Validate if a string is a valid room ID
 * @param roomId - The room ID to validate
 * @returns Boolean to indicate if the room ID is valid
 */
export declare function isValidRoomId(roomId: string): boolean;
/**
 * Validate if a string is a valid room alias
 * @param roomAlias - The room alias to validate
 * @returns Boolean to indicate if the room alias is valid
 */
export declare function isValidRoomAlias(roomAlias: string): boolean;
/**
 * Validate if a string is a valid mxc link
 * @param mxcLink - The mxc link to validate
 * @returns Boolean to indicate if the mxc link is valid
 */
export declare function isValidMxcLink(mxcLink: string): boolean;
/**
 * Validate if a string is a valid event ID
 * @param eventId - The event ID to validate
 * @returns Boolean to indicate if the event ID is valid
 */
export declare function isValidEventId(eventId: string): boolean;
/**
 * Validate if a string is a valid event type
 * @param eventType - The event type to validate
 * @returns Boolean to indicate if the event type is valid
 */
export declare function isValidEventType(eventType: string): boolean;
/**
 * Validate if a string is a valid collection ID
 * @param collectionId - The collection ID to validate
 * @returns Boolean to indicate if the collection ID is valid
 */
export declare function isValidCollectionId(collectionId: string): boolean;
/**
 * Validate if a string is a valid DID
 * @param did - The DID to validate
 * @returns Boolean to indicate if the DID is valid
 */
export declare function isValidDid(did: string): boolean;
/**
 * Validate if a string is a valid address
 * @param address - The address to validate
 * @returns Boolean to indicate if the address is valid
 */
export declare function isValidAddress(address: string): boolean;
/**
 * Validate if a string is a valid bid
 * @param bid - The bid to validate
 * @returns Boolean to indicate if the bid is valid
 */
export declare function isValidBid(bid: string): boolean;
/**
 * Validate if a string is a valid role
 * @param role - The role to validate
 * @returns Boolean to indicate if the role is valid
 */
export declare function isValidBidRole(role: string): boolean;
