export declare function cleanUrl(url: string): string;
