import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidRoomId } from '../../utils/validators';
export async function invite(roomId, botUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${botUrl}/invite`;
  const payload = {
    roomId: roomId
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}