import _defineProperty from "@babel/runtime/helpers/esm/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidBidRole, isValidCollectionId, isValidDid, isValidEventId } from '../../utils/validators';
export async function queryBids(collectionId, pagination, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'get-bids',
    flags: _objectSpread({
      collection: collectionId
    }, pagination !== null && pagination !== void 0 && pagination.nextPageToken ? {
      nextPageToken: pagination.nextPageToken
    } : {})
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryBidsByDid(collectionId, did, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'get-bids-by-did',
    flags: {
      collection: collectionId,
      did: did
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function submitBid(collectionId, bid, role, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidBidRole(role)) {
    throw new Error('Invalid role');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'submit-bid',
    flags: {
      collection: collectionId,
      value: bid,
      role: role
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}
export async function approveBid(bidId, collectionId, did, botUrl, accessToken) {
  if (!isValidEventId(bidId)) {
    throw new Error('Invalid bid ID');
  }
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'evaluate-bid',
    flags: {
      id: bidId,
      collection: collectionId,
      did: did,
      status: 'approved'
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}
export async function rejectBid(bidId, collectionId, did, reason, botUrl, accessToken) {
  if (!isValidEventId(bidId)) {
    throw new Error('Invalid bid ID');
  }
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'evaluate-bid',
    flags: {
      id: bidId,
      collection: collectionId,
      did: did,
      status: 'rejected',
      data: {
        reason: reason
      }
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}
export async function queryDidIsBlocked(collectionId, did, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'did-is-blocked',
    flags: {
      collection: collectionId,
      did: did
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}
export async function didBlock(collectionId, did, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'did-block',
    flags: {
      collection: collectionId,
      did: did
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}
export async function didUnblock(collectionId, did, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  if (!isValidDid(did)) {
    throw new Error('Invalid DID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'did-unblock',
    flags: {
      collection: collectionId,
      did: did
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data === null || data === void 0 ? void 0 : data.data;
}