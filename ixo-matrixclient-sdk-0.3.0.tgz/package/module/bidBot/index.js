import * as _1 from './bid/v1beta1';
import * as _2 from './bot/v1beta1';
let bidBot;
(function (_bidBot) {
  let bid;
  (function (_bid) {
    const v1beta1 = _bid.v1beta1 = _1;
  })(bid || (bid = _bidBot.bid || (_bidBot.bid = {})));
  let bot;
  (function (_bot) {
    const v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _bidBot.bot || (_bidBot.bot = {})));
})(bidBot || (bidBot = {}));
export function createMatrixBidBotClient({
  botUrl,
  accessToken
}) {
  return {
    bid: {
      v1beta1: {
        queryBids: (collectionId, pagination, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.queryBids(collectionId, pagination, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        queryBidsByDid: (collectionId, did, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.queryBidsByDid(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        submitBid: (collectionId, did, role, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.submitBid(collectionId, did, role, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        approveBid: (bidId, collectionId, did, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.approveBid(bidId, collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        rejectBid: (bidId, collectionId, did, reason, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.rejectBid(bidId, collectionId, did, reason, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        queryDidIsBlocked: (collectionId, did, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.queryDidIsBlocked(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        didBlock: (collectionId, did, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.didBlock(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        didUnblock: (collectionId, did, overrideBotUrl, overrideAccessToken) => bidBot.bid.v1beta1.didUnblock(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken)
      }
    },
    bot: {
      v1beta1: {
        invite: roomId => bidBot.bot.v1beta1.invite(roomId, botUrl, accessToken)
      }
    }
  };
}