import * as _1 from './mxc';
import * as _2 from './validators';
export let utils;
(function (_utils) {
  const mxc = _utils.mxc = _1;
  const validators = _utils.validators = _2;
})(utils || (utils = {}));