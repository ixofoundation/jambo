export async function throwResponseError(response) {
  const data = await response.json().catch(() => null);
  if (data !== undefined && data !== null) {
    console.log('throwResponseError', data);
    if (data !== null && data !== void 0 && data.error) {
      throw new Error(data.error);
    }
    if (data !== null && data !== void 0 && data.message) {
      throw new Error(data.message);
    }
    if (data !== null && data !== void 0 && data.errcode) {
      throw new Error(data.errcode);
    }
    if (typeof data === 'string') {
      throw new Error(data);
    }
    if (typeof data === 'object') {
      throw new Error(JSON.stringify(data));
    }
    if (data !== null && data !== void 0 && data.toString && typeof data.toString === 'function') {
      throw new Error(data.toString());
    }
  }
  const text = await response.text().catch(() => null);
  if (text) {
    throw new Error(text);
  }
  throw new Error(response.statusText);
}