/**
 * Validate if a string is a valid user ID
 * @param userId - The user ID to validate
 * @returns Boolean to indicate if the user ID is valid
 */
export function isValidUserId(userId) {
  const userIdRegex = /^@[a-zA-Z0-9._-]+:[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return userIdRegex.test(userId);
}
/**
 * Validate if a string is a valid room ID
 * @param roomId - The room ID to validate
 * @returns Boolean to indicate if the room ID is valid
 */
export function isValidRoomId(roomId) {
  const roomIdRegex = /^![a-zA-Z0-9._-]+:(?:localhost|\[.+\]|[a-zA-Z0-9.-]+)(?::\d+)?$/;
  return roomIdRegex.test(roomId);
}
/**
 * Validate if a string is a valid room alias
 * @param roomAlias - The room alias to validate
 * @returns Boolean to indicate if the room alias is valid
 */
export function isValidRoomAlias(roomAlias) {
  const roomAliasRegex = /^#[a-zA-Z0-9._-]+:(?:localhost|\[.+\]|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(?::\d+)?$/;
  return roomAliasRegex.test(roomAlias);
}
/**
 * Validate if a string is a valid mxc link
 * @param mxcLink - The mxc link to validate
 * @returns Boolean to indicate if the mxc link is valid
 */
export function isValidMxcLink(mxcLink) {
  const mxcLinkRegex = /^mxc:\/\/[a-zA-Z0-9.-]+\/[a-zA-Z0-9._-]+$/;
  return mxcLinkRegex.test(mxcLink);
}
/**
 * Validate if a string is a valid event ID
 * @param eventId - The event ID to validate
 * @returns Boolean to indicate if the event ID is valid
 */
export function isValidEventId(eventId) {
  // eventId must be string, length longer than 5 and start with $
  const eventIdRegex = /^\$[\w-]+$/;
  return eventIdRegex.test(eventId);
}
/**
 * Validate if a string is a valid event type
 * @param eventType - The event type to validate
 * @returns Boolean to indicate if the event type is valid
 */
export function isValidEventType(eventType) {
  const eventTypeRegex = /^[a-zA-Z0-9._-]+$/;
  return eventTypeRegex.test(eventType);
}
/**
 * Validate if a string is a valid collection ID
 * @param collectionId - The collection ID to validate
 * @returns Boolean to indicate if the collection ID is valid
 */
export function isValidCollectionId(collectionId) {
  const collectionIdRegex = /^[0-9]+$/;
  return collectionIdRegex.test(collectionId);
}
/**
 * Validate if a string is a valid DID
 * @param did - The DID to validate
 * @returns Boolean to indicate if the DID is valid
 */
export function isValidDid(did) {
  const didRegex = /^did:(ixo|x):[a-zA-Z0-9._-]+$/;
  return didRegex.test(did);
}
/**
 * Validate if a string is a valid address
 * @param address - The address to validate
 * @returns Boolean to indicate if the address is valid
 */
export function isValidAddress(address) {
  const addressRegex = /^ixo1[a-zA-Z0-9]+$/;
  return addressRegex.test(address);
}
/**
 * Validate if a string is a valid bid
 * @param bid - The bid to validate
 * @returns Boolean to indicate if the bid is valid
 */
export function isValidBid(bid) {
  return typeof bid === 'string';
}
/**
 * Validate if a string is a valid role
 * @param role - The role to validate
 * @returns Boolean to indicate if the role is valid
 */
export function isValidBidRole(role) {
  return role === 'PO' || role === 'EA' || role === 'SA' || role === 'IA';
}