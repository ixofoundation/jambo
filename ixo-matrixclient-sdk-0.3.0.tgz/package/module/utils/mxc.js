import { isValidMxcLink } from './validators';
/**
 * Encode a dictionary of query parameters.
 * Omits any undefined/null values.
 * @param params - A dict of key/values to encode e.g.
 * `{"foo": "bar", "baz": "taz"}`
 * @returns The encoded string e.g. foo=bar&baz=taz
 */
function encodeParams(params, urlSearchParams) {
  const searchParams = urlSearchParams !== null && urlSearchParams !== void 0 ? urlSearchParams : new URLSearchParams();
  for (const [key, val] of Object.entries(params)) {
    if (val !== undefined && val !== null) {
      if (Array.isArray(val)) {
        val.forEach(v => {
          searchParams.append(key, String(v));
        });
      } else {
        searchParams.append(key, String(val));
      }
    }
  }
  return searchParams;
}

/**
 * Get the HTTP URL for an MXC URI.
 * @param baseUrl - The base homeserver url which has a content repo.
 * @param mxc - The mxc:// URI.
 * @param width - The desired width of the thumbnail.
 * @param height - The desired height of the thumbnail.
 * @param resizeMethod - The thumbnail resize method to use, either
 * "crop" or "scale".
 * @param allowDirectLinks - If true, return any non-mxc URLs
 * directly. Fetching such URLs will leak information about the user to
 * anyone they share a room with. If false, will return the emptry string
 * for such URLs.
 * @returns The complete URL to the content.
 */
function getHttpUriForMxc(baseUrl, mxc, width, height, resizeMethod, allowDirectLinks = false) {
  if (typeof mxc !== 'string' || !mxc) {
    return '';
  }
  if (mxc.indexOf('mxc://') !== 0) {
    if (allowDirectLinks) {
      return mxc;
    } else {
      return '';
    }
  }
  let serverAndMediaId = mxc.slice(6); // strips mxc://
  let prefix = '/_matrix/media/v3/download/';
  const params = {};
  if (width) {
    params['width'] = Math.round(width).toString();
  }
  if (height) {
    params['height'] = Math.round(height).toString();
  }
  if (resizeMethod) {
    params['method'] = resizeMethod;
  }
  if (Object.keys(params).length > 0) {
    // these are thumbnailing params so they probably want the
    // thumbnailing API...
    prefix = '/_matrix/media/v3/thumbnail/';
  }
  const fragmentOffset = serverAndMediaId.indexOf('#');
  let fragment = '';
  if (fragmentOffset >= 0) {
    fragment = serverAndMediaId.slice(fragmentOffset);
    serverAndMediaId = serverAndMediaId.slice(0, fragmentOffset);
  }
  const urlParams = Object.keys(params).length === 0 ? '' : '?' + encodeParams(params);
  return baseUrl + prefix + serverAndMediaId + urlParams + fragment;
}

/**
 * Turn an MXC URL into an HTTP one. <strong>This method is experimental and
 * may change.</strong>
 * @param mxcUrl - The MXC URL
 * @param width - The desired width of the thumbnail.
 * @param height - The desired height of the thumbnail.
 * @param resizeMethod - The thumbnail resize method to use, either
 * "crop" or "scale".
 * @param allowDirectLinks - If true, return any non-mxc URLs
 * directly. Fetching such URLs will leak information about the user to
 * anyone they share a room with. If false, will return null for such URLs.
 * @returns the avatar URL or null.
 */
export function mxcUrlToHttp(baseUrl, mxcUrl, width, height, resizeMethod, allowDirectLinks) {
  if (!isValidMxcLink(mxcUrl)) {
    console.warn(`Invalid mxc: ${mxcUrl}`);
    return mxcUrl;
  }
  return getHttpUriForMxc(baseUrl, mxcUrl, width, height, resizeMethod, allowDirectLinks);
}