export function cleanUrl(url) {
  // Remove line breakers such as \n and any other whitespace characters
  let cleanUrl = url.replace(/[\n\r\s]/g, '');

  // Regular expression to match duplicate slashes except for the first one after "https://" or "http://"
  const regex = /(https?:\/\/|[^:])\/\//g;

  // Replace duplicate slashes with a single slash, excluding the first one after "https://" or "http://"
  cleanUrl = cleanUrl.replace(regex, (match, p1, offset, string) => {
    // If match starts with http: or https:, keep it as it is.
    if (p1 === 'http://' || p1 === 'https://') {
      return match;
    } else {
      // Otherwise, replace the extra slashes with a single slash
      return p1 + '/';
    }
  });
  return cleanUrl;
}