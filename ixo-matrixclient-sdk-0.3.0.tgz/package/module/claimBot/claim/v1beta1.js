import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidCollectionId } from '../../utils/validators';
export async function queryClaim(collectionId, cid, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'get-claim',
    flags: {
      collection: collectionId,
      cid: cid
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function saveClaim(collectionId, claim, botUrl, accessToken) {
  if (!isValidCollectionId(collectionId)) {
    throw new Error('Invalid collection ID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'save-claim',
    flags: {
      collection: collectionId,
      data: claim
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}