import * as _1 from './claim/v1beta1';
import * as _2 from './bot/v1beta1';
let claimBot;
(function (_claimBot) {
  let claim;
  (function (_claim) {
    const v1beta1 = _claim.v1beta1 = _1;
  })(claim || (claim = _claimBot.claim || (_claimBot.claim = {})));
  let bot;
  (function (_bot) {
    const v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _claimBot.bot || (_claimBot.bot = {})));
})(claimBot || (claimBot = {}));
export function createMatrixClaimBotClient({
  botUrl,
  accessToken
}) {
  return {
    claim: {
      v1beta1: {
        queryClaim: (collectionId, cid) => claimBot.claim.v1beta1.queryClaim(collectionId, cid, botUrl, accessToken),
        saveClaim: (collectionId, claim) => claimBot.claim.v1beta1.saveClaim(collectionId, claim, botUrl, accessToken)
      }
    },
    bot: {
      v1beta1: {
        invite: roomId => claimBot.bot.v1beta1.invite(roomId, botUrl, accessToken)
      }
    }
  };
}