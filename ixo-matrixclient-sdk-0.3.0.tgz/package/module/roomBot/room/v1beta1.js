import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { join } from '../../api/room/v1beta1';
// WIll only create room if not exists yet
export async function sourceRoom(did, botUrl, accessToken) {
  const url = `${botUrl}/room/source`;
  const payload = {
    did: did
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function sourceRoomAndJoin(did, homeServerUrl, botUrl, accessToken) {
  const createRoomResponse = await sourceRoom(did, botUrl, accessToken);
  console.log('createRoomResponse', createRoomResponse);
  if (!createRoomResponse.roomId) {
    throw new Error('Room ID not found');
  }
  const roomId = createRoomResponse.roomId;
  const joinRoomResponse = await join(roomId, homeServerUrl, accessToken);
  if (!joinRoomResponse.room_id) {
    throw new Error('Failed to join created room');
  }
  if (joinRoomResponse.room_id !== roomId) {
    throw new Error('Joined room ID does not match created room ID');
  }
  return createRoomResponse;
}
export async function roomInvite(did, botUrl, accessToken) {
  const url = `${botUrl}/room/invite`;
  const payload = {
    did: did
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function roomInviteAndJoin(did, homeServerUrl, botUrl, accessToken) {
  const roomInviteResponse = await roomInvite(did, botUrl, accessToken);
  if (!roomInviteResponse.roomId) {
    throw new Error('Room ID not found');
  }
  const roomId = roomInviteResponse.roomId;
  const joinRoomResponse = await join(roomId, homeServerUrl, accessToken);
  if (!joinRoomResponse.room_id) {
    throw new Error('Failed to join room invite');
  }
  if (joinRoomResponse.room_id !== roomId) {
    throw new Error('Joined room ID does not invited room ID');
  }
  return roomInviteResponse;
}