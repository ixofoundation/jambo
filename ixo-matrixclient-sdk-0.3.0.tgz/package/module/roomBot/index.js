import * as _1 from './room/v1beta1';
let roomBot;
(function (_roomBot) {
  let room;
  (function (_room) {
    const v1beta1 = _room.v1beta1 = _1;
  })(room || (room = _roomBot.room || (_roomBot.room = {})));
})(roomBot || (roomBot = {}));
export function createMatrixRoomBotClient({
  homeServerUrl,
  botUrl,
  accessToken
}) {
  return {
    room: {
      v1beta1: {
        sourceRoom: (did, overrideBotUrl, overrideAccessToken) => roomBot.room.v1beta1.sourceRoom(did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        sourceRoomAndJoin: (did, overrideHomeServerUrl, overrideBotUrl, overrideAccessToken) => roomBot.room.v1beta1.sourceRoomAndJoin(did, overrideHomeServerUrl || homeServerUrl, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        roomInvite: (did, overrideBotUrl, overrideAccessToken) => roomBot.room.v1beta1.roomInvite(did, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        roomInviteAndJoin: (did, overrideHomeServerUrl, overrideBotUrl, overrideAccessToken) => roomBot.room.v1beta1.roomInviteAndJoin(did, overrideHomeServerUrl || homeServerUrl, overrideBotUrl || botUrl, overrideAccessToken || accessToken)
      }
    }
  };
}