import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { cleanUrl } from '../../utils/url';
export let UploadContentType = /*#__PURE__*/function (UploadContentType) {
  UploadContentType["PDF"] = "application/pdf";
  UploadContentType["JPEG"] = "image/jpeg";
  UploadContentType["PNG"] = "image/png";
  UploadContentType["GIF"] = "image/gif";
  UploadContentType["BMP"] = "image/bmp";
  UploadContentType["SVG"] = "image/svg+xml";
  UploadContentType["TIFF"] = "image/tiff";
  UploadContentType["WEBP"] = "image/webp";
  UploadContentType["PLAIN_TEXT"] = "text/plain";
  UploadContentType["CSV"] = "text/csv";
  UploadContentType["HTML"] = "text/html";
  UploadContentType["ZIP"] = "application/zip";
  UploadContentType["GZIP"] = "application/gzip";
  UploadContentType["MULTIPART_FORM_DATA"] = "multipart/form-data";
  return UploadContentType;
}({});
export async function upload(filename, type, file, homeServerUrl, accessToken) {
  if (!filename) {
    throw new Error("'filename' is required to upload content");
  }
  if (!type) {
    throw new Error("'type' is required to upload content");
  }
  if (!file) {
    throw new Error("'file' is required to upload content");
  }
  let url = `${homeServerUrl}/_matrix/media/v3/upload`;
  url = cleanUrl(url);
  url += `?filename=${encodeURIComponent(filename)}`;
  const response = await fetch(cleanUrl(url), {
    method: 'POST',
    headers: {
      'Content-Type': type,
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    },
    body: file
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = response.json();
  return data;
}