import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidEventId, isValidEventType, isValidRoomId } from '../../utils/validators';
export async function queryEvent(roomId, eventId, homeServerUrl, accessToken) {
  console.log('queryEvent', roomId, eventId, homeServerUrl, accessToken);
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  if (!isValidEventId(eventId)) {
    throw new Error('Invalid event ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/event/${encodeURIComponent(eventId)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryChildEvents(roomId, parentEventId, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  if (!isValidEventId(parentEventId)) {
    throw new Error('Invalid parent event ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v1/rooms/${encodeURIComponent(roomId)}/relations/${encodeURIComponent(parentEventId)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryChildEventsByRelType(roomId, parentEventId, relType, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  if (!isValidEventId(parentEventId)) {
    throw new Error('Invalid parent event ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v1/rooms/${encodeURIComponent(roomId)}/relations/${encodeURIComponent(parentEventId)}/${encodeURIComponent(relType)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryChildEventsByRelTypeAndEventType(roomId, parentEventId, relType, eventType, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  if (!isValidEventId(parentEventId)) {
    throw new Error('Invalid parent event ID');
  }
  if (!isValidEventType(eventType)) {
    throw new Error('Invalid event type');
  }
  const url = `${homeServerUrl}/_matrix/client/v1/rooms/${encodeURIComponent(roomId)}/relations/${encodeURIComponent(parentEventId)}/${encodeURIComponent(relType)}/${encodeURIComponent(eventType)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}