import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
export async function queryWhoAmI(homeServerUrl, accessToken) {
  if (!accessToken) {
    throw new Error('AccessToken cannot be empty');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/account/whoami`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}