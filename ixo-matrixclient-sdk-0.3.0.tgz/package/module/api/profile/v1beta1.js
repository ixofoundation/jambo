import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidMxcLink, isValidUserId } from '../../utils/validators';
export async function queryProfile(userId, homeServerUrl, accessToken) {
  if (!isValidUserId(userId)) {
    throw new Error('Invalid userId');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/profile/${encodeURIComponent(userId)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryDisplayname(userId, homeServerUrl, accessToken) {
  if (!isValidUserId(userId)) {
    throw new Error('Invalid userId');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/profile/${encodeURIComponent(userId)}/displayname`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data.displayname;
}
export async function queryAvatarUrl(userId, homeServerUrl, accessToken) {
  if (!isValidUserId(userId)) {
    throw new Error('Invalid userId');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/profile/${encodeURIComponent(userId)}/avatar_url`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data.avatar_url;
}
export async function setDisplayname(userId, displayname, homeServerUrl, accessToken) {
  var _data$displayname;
  if (!isValidUserId(userId)) {
    throw new Error('Invalid userId');
  }
  if (!displayname) {
    throw new Error('Displayname cannot be empty');
  }
  if (typeof displayname !== 'string') {
    throw new Error('Displayname must be a string');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/profile/${encodeURIComponent(userId)}/displayname`;
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify({
      displayname: displayname
    })
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return (_data$displayname = data.displayname) !== null && _data$displayname !== void 0 ? _data$displayname : displayname;
}
export async function setAvatarUrl(userId, avatarUrl, homeServerUrl, accessToken) {
  var _data$avatar_url;
  if (!isValidUserId(userId)) {
    throw new Error('Invalid userId');
  }
  if (!avatarUrl) {
    throw new Error('Avatar URL cannot be empty');
  }
  if (typeof avatarUrl !== 'string') {
    throw new Error('Avatar URL must be a string');
  }
  if (!isValidMxcLink(avatarUrl)) {
    throw new Error('Invalid avatar URL');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/profile/${encodeURIComponent(userId)}/avatar_url`;
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify({
      avatar_url: avatarUrl
    })
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return (_data$avatar_url = data.avatar_url) !== null && _data$avatar_url !== void 0 ? _data$avatar_url : avatarUrl;
}