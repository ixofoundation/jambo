import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidRoomAlias, isValidRoomId, isValidUserId } from '../../utils/validators';
export async function queryId(alias, homeServerUrl, accessToken) {
  if (!isValidRoomAlias(alias)) {
    throw new Error('Invalid room alias');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/directory/room/${encodeURIComponent(alias)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function queryVisibility(roomId, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid roomId');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/directory/list/room/${encodeURIComponent(roomId)}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function setVisibility(roomId, visibility, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/directory/list/room/${encodeURIComponent(roomId)}`;
  const payload = {
    visibility: visibility
  };
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function knock(roomIdOrAlias, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomIdOrAlias)) {
    throw new Error('Invalid room ID or alias');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/knock/${encodeURIComponent(roomIdOrAlias)}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function join(roomIdOrAlias, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomIdOrAlias)) {
    throw new Error('Invalid room ID or alias');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/join/${encodeURIComponent(roomIdOrAlias)}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function listJoinedRooms(homeServerUrl, accessToken) {
  const url = `${homeServerUrl}/_matrix/client/v3/joined_rooms`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function listJoinedMembers(roomId, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/joined_members`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function leave(roomId, reason, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/leave`;
  const payload = {
    reason: reason
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function kick(roomId, userId, reason, homeServerUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  if (!isValidUserId(userId)) {
    throw new Error('Invalid user ID');
  }
  const url = `${homeServerUrl}/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/kick`;
  const payload = {
    user_id: userId,
    reason: reason
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}