import * as _1 from './media/v1beta1';
import * as _2 from './profile/v1beta1';
import * as _3 from './room/v1beta1';
import * as _4 from './account/v1beta1';
import * as _5 from './event/v1beta1';
let api;
(function (_api) {
  let media;
  (function (_media) {
    const v1beta1 = _media.v1beta1 = _1;
  })(media || (media = _api.media || (_api.media = {})));
  let profile;
  (function (_profile) {
    const v1beta1 = _profile.v1beta1 = _2;
  })(profile || (profile = _api.profile || (_api.profile = {})));
  let room;
  (function (_room) {
    const v1beta1 = _room.v1beta1 = _3;
  })(room || (room = _api.room || (_api.room = {})));
  let account;
  (function (_account) {
    const v1beta1 = _account.v1beta1 = _4;
  })(account || (account = _api.account || (_api.account = {})));
  let event;
  (function (_event) {
    const v1beta1 = _event.v1beta1 = _5;
  })(event || (event = _api.event || (_api.event = {})));
})(api || (api = {}));
export function createMatrixApiClient({
  homeServerUrl,
  accessToken
}) {
  return {
    media: {
      v1beta1: {
        upload: (filename, type, file, overrideHomeServerUrl, overrideAccessToken) => api.media.v1beta1.upload(filename, type, file, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken)
      }
    },
    profile: {
      v1beta1: {
        queryProfile: (userId, overrideHomeServerUrl, overrideAccessToken) => api.profile.v1beta1.queryProfile(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryDisplayname: (userId, overrideHomeServerUrl, overrideAccessToken) => api.profile.v1beta1.queryDisplayname(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryAvatarUrl: (userId, overrideHomeServerUrl, overrideAccessToken) => api.profile.v1beta1.queryAvatarUrl(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        setDisplayname: (userId, displayname, overrideHomeServerUrl, overrideAccessToken) => api.profile.v1beta1.setDisplayname(userId, displayname, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        setAvatarUrl: (userId, avatarUrl, overrideHomeServerUrl, overrideAccessToken) => api.profile.v1beta1.setAvatarUrl(userId, avatarUrl, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken)
      }
    },
    account: {
      v1beta1: {
        queryWhoAmI: (overrideHomeServerUrl, overrideAccessToken) => api.account.v1beta1.queryWhoAmI(overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken)
      }
    },
    room: {
      v1beta1: {
        queryId: (alias, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.queryId(alias, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryVisibility: (roomId, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.queryVisibility(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        setVisibility: (roomId, visibility, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.setVisibility(roomId, visibility, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        knock: (roomIdOrAlias, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.knock(roomIdOrAlias, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        join: (roomId, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.join(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        listJoinedRooms: (overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.listJoinedRooms(overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        listJoinedMembers: (roomId, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.listJoinedMembers(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        leave: (roomId, reason, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.leave(roomId, reason, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        kick: (roomId, userId, reason, overrideHomeServerUrl, overrideAccessToken) => api.room.v1beta1.kick(roomId, userId, reason, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken)
      }
    },
    event: {
      v1beta1: {
        queryEvent: (roomId, eventId, overrideHomeServerUrl, overrideAccessToken) => api.event.v1beta1.queryEvent(roomId, eventId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryChildEvents: (roomId, parentEventId, overrideHomeServerUrl, overrideAccessToken) => api.event.v1beta1.queryChildEvents(roomId, parentEventId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryChildEventsByRelType: (roomId, parentEventId, relType, overrideHomeServerUrl, overrideAccessToken) => api.event.v1beta1.queryChildEventsByRelType(roomId, parentEventId, relType, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken),
        queryChildEventsByRelTypeAndEventType: (roomId, parentEventId, relType, eventType, overrideHomeServerUrl, overrideAccessToken) => api.event.v1beta1.queryChildEventsByRelTypeAndEventType(roomId, parentEventId, relType, eventType, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken)
      }
    }
  };
}