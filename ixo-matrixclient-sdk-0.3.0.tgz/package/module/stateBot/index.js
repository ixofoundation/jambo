import * as _1 from './acl/v1beta1';
import * as _2 from './bot/v1beta1';
import * as _3 from './state/v1beta1';
let stateBot;
(function (_stateBot) {
  let acl;
  (function (_acl) {
    const v1beta1 = _acl.v1beta1 = _1;
  })(acl || (acl = _stateBot.acl || (_stateBot.acl = {})));
  let bot;
  (function (_bot) {
    const v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _stateBot.bot || (_stateBot.bot = {})));
  let state;
  (function (_state) {
    const v1beta1 = _state.v1beta1 = _3;
  })(state || (state = _stateBot.state || (_stateBot.state = {})));
})(stateBot || (stateBot = {}));
export function createMatrixStateBotClient({
  botUrl,
  accessToken
}) {
  return {
    acl: {
      v1beta1: {
        queryAcl: (roomId, key, path, overrideBotUrl, overrideAccessToken) => stateBot.acl.v1beta1.queryAcl(roomId, key, path, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        setAcl: (roomId, key, path, value, overrideBotUrl, overrideAccessToken) => stateBot.acl.v1beta1.setAcl(roomId, key, path, value, overrideBotUrl || botUrl, overrideAccessToken || accessToken)
      }
    },
    bot: {
      v1beta1: {
        invite: (roomId, overrideBotUrl, overrideAccessToken) => stateBot.bot.v1beta1.invite(roomId, overrideBotUrl || botUrl, overrideAccessToken || accessToken)
      }
    },
    state: {
      v1beta1: {
        queryState: (roomId, key, path, overrideBotUrl, overrideAccessToken) => stateBot.state.v1beta1.queryState(roomId, key, path, overrideBotUrl || botUrl, overrideAccessToken || accessToken),
        setState: (roomId, key, path, value, overrideBotUrl, overrideAccessToken) => stateBot.state.v1beta1.setState(roomId, key, path, value, overrideBotUrl || botUrl, overrideAccessToken || accessToken)
      }
    }
  };
}