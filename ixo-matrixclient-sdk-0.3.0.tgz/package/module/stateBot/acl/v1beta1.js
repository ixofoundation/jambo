import fetch from 'node-fetch';
import { throwResponseError } from '../../utils/error';
import { isValidRoomId } from '../../utils/validators';
export async function queryAcl(roomId, key, path, botUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'get-acl',
    roomId: roomId,
    flags: {
      key: key,
      path: path
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}
export async function setAcl(roomId, key, path, value, botUrl, accessToken) {
  if (!isValidRoomId(roomId)) {
    throw new Error('Invalid room ID');
  }
  const url = `${botUrl}/action`;
  const payload = {
    action: 'set-acl',
    roomId: roomId,
    flags: {
      key: key,
      path: path,
      value: value
    }
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: accessToken ? `Bearer ${accessToken}` : undefined
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    await throwResponseError(response);
  }
  const data = await response.json();
  return data;
}