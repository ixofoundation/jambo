"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMatrixClaimBotClient = createMatrixClaimBotClient;
var _1 = _interopRequireWildcard(require("./claim/v1beta1"));
var _2 = _interopRequireWildcard(require("./bot/v1beta1"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { "default": e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n["default"] = e, t && t.set(e, n), n; }
var claimBot;
(function (_claimBot) {
  var claim;
  (function (_claim) {
    var v1beta1 = _claim.v1beta1 = _1;
  })(claim || (claim = _claimBot.claim || (_claimBot.claim = {})));
  var bot;
  (function (_bot) {
    var v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _claimBot.bot || (_claimBot.bot = {})));
})(claimBot || (claimBot = {}));
function createMatrixClaimBotClient(_ref) {
  var botUrl = _ref.botUrl,
    accessToken = _ref.accessToken;
  return {
    claim: {
      v1beta1: {
        queryClaim: function queryClaim(collectionId, cid) {
          return claimBot.claim.v1beta1.queryClaim(collectionId, cid, botUrl, accessToken);
        },
        saveClaim: function saveClaim(collectionId, claim) {
          return claimBot.claim.v1beta1.saveClaim(collectionId, claim, botUrl, accessToken);
        }
      }
    },
    bot: {
      v1beta1: {
        invite: function invite(roomId) {
          return claimBot.bot.v1beta1.invite(roomId, botUrl, accessToken);
        }
      }
    }
  };
}