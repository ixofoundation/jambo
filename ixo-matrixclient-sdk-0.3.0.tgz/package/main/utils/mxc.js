"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.mxcUrlToHttp = mxcUrlToHttp;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _validators = require("./validators");
/**
 * Encode a dictionary of query parameters.
 * Omits any undefined/null values.
 * @param params - A dict of key/values to encode e.g.
 * `{"foo": "bar", "baz": "taz"}`
 * @returns The encoded string e.g. foo=bar&baz=taz
 */
function encodeParams(params, urlSearchParams) {
  var searchParams = urlSearchParams !== null && urlSearchParams !== void 0 ? urlSearchParams : new URLSearchParams();
  var _loop = function _loop() {
    var _Object$entries$_i = (0, _slicedToArray2["default"])(_Object$entries[_i], 2),
      key = _Object$entries$_i[0],
      val = _Object$entries$_i[1];
    if (val !== undefined && val !== null) {
      if (Array.isArray(val)) {
        val.forEach(function (v) {
          searchParams.append(key, String(v));
        });
      } else {
        searchParams.append(key, String(val));
      }
    }
  };
  for (var _i = 0, _Object$entries = Object.entries(params); _i < _Object$entries.length; _i++) {
    _loop();
  }
  return searchParams;
}

/**
 * Get the HTTP URL for an MXC URI.
 * @param baseUrl - The base homeserver url which has a content repo.
 * @param mxc - The mxc:// URI.
 * @param width - The desired width of the thumbnail.
 * @param height - The desired height of the thumbnail.
 * @param resizeMethod - The thumbnail resize method to use, either
 * "crop" or "scale".
 * @param allowDirectLinks - If true, return any non-mxc URLs
 * directly. Fetching such URLs will leak information about the user to
 * anyone they share a room with. If false, will return the emptry string
 * for such URLs.
 * @returns The complete URL to the content.
 */
function getHttpUriForMxc(baseUrl, mxc, width, height, resizeMethod) {
  var allowDirectLinks = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : false;
  if (typeof mxc !== 'string' || !mxc) {
    return '';
  }
  if (mxc.indexOf('mxc://') !== 0) {
    if (allowDirectLinks) {
      return mxc;
    } else {
      return '';
    }
  }
  var serverAndMediaId = mxc.slice(6); // strips mxc://
  var prefix = '/_matrix/media/v3/download/';
  var params = {};
  if (width) {
    params['width'] = Math.round(width).toString();
  }
  if (height) {
    params['height'] = Math.round(height).toString();
  }
  if (resizeMethod) {
    params['method'] = resizeMethod;
  }
  if (Object.keys(params).length > 0) {
    // these are thumbnailing params so they probably want the
    // thumbnailing API...
    prefix = '/_matrix/media/v3/thumbnail/';
  }
  var fragmentOffset = serverAndMediaId.indexOf('#');
  var fragment = '';
  if (fragmentOffset >= 0) {
    fragment = serverAndMediaId.slice(fragmentOffset);
    serverAndMediaId = serverAndMediaId.slice(0, fragmentOffset);
  }
  var urlParams = Object.keys(params).length === 0 ? '' : '?' + encodeParams(params);
  return baseUrl + prefix + serverAndMediaId + urlParams + fragment;
}

/**
 * Turn an MXC URL into an HTTP one. <strong>This method is experimental and
 * may change.</strong>
 * @param mxcUrl - The MXC URL
 * @param width - The desired width of the thumbnail.
 * @param height - The desired height of the thumbnail.
 * @param resizeMethod - The thumbnail resize method to use, either
 * "crop" or "scale".
 * @param allowDirectLinks - If true, return any non-mxc URLs
 * directly. Fetching such URLs will leak information about the user to
 * anyone they share a room with. If false, will return null for such URLs.
 * @returns the avatar URL or null.
 */
function mxcUrlToHttp(baseUrl, mxcUrl, width, height, resizeMethod, allowDirectLinks) {
  if (!(0, _validators.isValidMxcLink)(mxcUrl)) {
    console.warn("Invalid mxc: ".concat(mxcUrl));
    return mxcUrl;
  }
  return getHttpUriForMxc(baseUrl, mxcUrl, width, height, resizeMethod, allowDirectLinks);
}