"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isValidAddress = isValidAddress;
exports.isValidBid = isValidBid;
exports.isValidBidRole = isValidBidRole;
exports.isValidCollectionId = isValidCollectionId;
exports.isValidDid = isValidDid;
exports.isValidEventId = isValidEventId;
exports.isValidEventType = isValidEventType;
exports.isValidMxcLink = isValidMxcLink;
exports.isValidRoomAlias = isValidRoomAlias;
exports.isValidRoomId = isValidRoomId;
exports.isValidUserId = isValidUserId;
/**
 * Validate if a string is a valid user ID
 * @param userId - The user ID to validate
 * @returns Boolean to indicate if the user ID is valid
 */
function isValidUserId(userId) {
  var userIdRegex = /^@[a-zA-Z0-9._-]+:[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return userIdRegex.test(userId);
}
/**
 * Validate if a string is a valid room ID
 * @param roomId - The room ID to validate
 * @returns Boolean to indicate if the room ID is valid
 */
function isValidRoomId(roomId) {
  var roomIdRegex = /^![a-zA-Z0-9._-]+:(?:localhost|\[.+\]|[a-zA-Z0-9.-]+)(?::\d+)?$/;
  return roomIdRegex.test(roomId);
}
/**
 * Validate if a string is a valid room alias
 * @param roomAlias - The room alias to validate
 * @returns Boolean to indicate if the room alias is valid
 */
function isValidRoomAlias(roomAlias) {
  var roomAliasRegex = /^#[a-zA-Z0-9._-]+:(?:localhost|\[.+\]|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(?::\d+)?$/;
  return roomAliasRegex.test(roomAlias);
}
/**
 * Validate if a string is a valid mxc link
 * @param mxcLink - The mxc link to validate
 * @returns Boolean to indicate if the mxc link is valid
 */
function isValidMxcLink(mxcLink) {
  var mxcLinkRegex = /^mxc:\/\/[a-zA-Z0-9.-]+\/[a-zA-Z0-9._-]+$/;
  return mxcLinkRegex.test(mxcLink);
}
/**
 * Validate if a string is a valid event ID
 * @param eventId - The event ID to validate
 * @returns Boolean to indicate if the event ID is valid
 */
function isValidEventId(eventId) {
  // eventId must be string, length longer than 5 and start with $
  var eventIdRegex = /^\$[\w-]+$/;
  return eventIdRegex.test(eventId);
}
/**
 * Validate if a string is a valid event type
 * @param eventType - The event type to validate
 * @returns Boolean to indicate if the event type is valid
 */
function isValidEventType(eventType) {
  var eventTypeRegex = /^[a-zA-Z0-9._-]+$/;
  return eventTypeRegex.test(eventType);
}
/**
 * Validate if a string is a valid collection ID
 * @param collectionId - The collection ID to validate
 * @returns Boolean to indicate if the collection ID is valid
 */
function isValidCollectionId(collectionId) {
  var collectionIdRegex = /^[0-9]+$/;
  return collectionIdRegex.test(collectionId);
}
/**
 * Validate if a string is a valid DID
 * @param did - The DID to validate
 * @returns Boolean to indicate if the DID is valid
 */
function isValidDid(did) {
  var didRegex = /^did:(ixo|x):[a-zA-Z0-9._-]+$/;
  return didRegex.test(did);
}
/**
 * Validate if a string is a valid address
 * @param address - The address to validate
 * @returns Boolean to indicate if the address is valid
 */
function isValidAddress(address) {
  var addressRegex = /^ixo1[a-zA-Z0-9]+$/;
  return addressRegex.test(address);
}
/**
 * Validate if a string is a valid bid
 * @param bid - The bid to validate
 * @returns Boolean to indicate if the bid is valid
 */
function isValidBid(bid) {
  return typeof bid === 'string';
}
/**
 * Validate if a string is a valid role
 * @param role - The role to validate
 * @returns Boolean to indicate if the role is valid
 */
function isValidBidRole(role) {
  return role === 'PO' || role === 'EA' || role === 'SA' || role === 'IA';
}