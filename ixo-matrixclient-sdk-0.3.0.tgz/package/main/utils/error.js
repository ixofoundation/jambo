"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.throwResponseError = throwResponseError;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
function throwResponseError(_x) {
  return _throwResponseError.apply(this, arguments);
}
function _throwResponseError() {
  _throwResponseError = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(response) {
    var data, text;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return response.json()["catch"](function () {
            return null;
          });
        case 2:
          data = _context.sent;
          if (!(data !== undefined && data !== null)) {
            _context.next = 17;
            break;
          }
          console.log('throwResponseError', data);
          if (!(data !== null && data !== void 0 && data.error)) {
            _context.next = 7;
            break;
          }
          throw new Error(data.error);
        case 7:
          if (!(data !== null && data !== void 0 && data.message)) {
            _context.next = 9;
            break;
          }
          throw new Error(data.message);
        case 9:
          if (!(data !== null && data !== void 0 && data.errcode)) {
            _context.next = 11;
            break;
          }
          throw new Error(data.errcode);
        case 11:
          if (!(typeof data === 'string')) {
            _context.next = 13;
            break;
          }
          throw new Error(data);
        case 13:
          if (!((0, _typeof2["default"])(data) === 'object')) {
            _context.next = 15;
            break;
          }
          throw new Error(JSON.stringify(data));
        case 15:
          if (!(data !== null && data !== void 0 && data.toString && typeof data.toString === 'function')) {
            _context.next = 17;
            break;
          }
          throw new Error(data.toString());
        case 17:
          _context.next = 19;
          return response.text()["catch"](function () {
            return null;
          });
        case 19:
          text = _context.sent;
          if (!text) {
            _context.next = 22;
            break;
          }
          throw new Error(text);
        case 22:
          throw new Error(response.statusText);
        case 23:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _throwResponseError.apply(this, arguments);
}