"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.approveBid = approveBid;
exports.didBlock = didBlock;
exports.didUnblock = didUnblock;
exports.queryBids = queryBids;
exports.queryBidsByDid = queryBidsByDid;
exports.queryDidIsBlocked = queryDidIsBlocked;
exports.rejectBid = rejectBid;
exports.submitBid = submitBid;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2["default"])(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function queryBids(_x, _x2, _x3, _x4) {
  return _queryBids.apply(this, arguments);
}
function _queryBids() {
  _queryBids = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(collectionId, pagination, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'get-bids',
            flags: _objectSpread({
              collection: collectionId
            }, pagination !== null && pagination !== void 0 && pagination.nextPageToken ? {
              nextPageToken: pagination.nextPageToken
            } : {})
          };
          _context.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context.sent;
          if (response.ok) {
            _context.next = 10;
            break;
          }
          _context.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context.next = 12;
          return response.json();
        case 12:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 14:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryBids.apply(this, arguments);
}
function queryBidsByDid(_x5, _x6, _x7, _x8) {
  return _queryBidsByDid.apply(this, arguments);
}
function _queryBidsByDid() {
  _queryBidsByDid = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(collectionId, did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context2.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          if ((0, _validators.isValidDid)(did)) {
            _context2.next = 4;
            break;
          }
          throw new Error('Invalid DID');
        case 4:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'get-bids-by-did',
            flags: {
              collection: collectionId,
              did: did
            }
          };
          _context2.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context2.sent;
          if (response.ok) {
            _context2.next = 12;
            break;
          }
          _context2.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context2.next = 14;
          return response.json();
        case 14:
          data = _context2.sent;
          return _context2.abrupt("return", data);
        case 16:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _queryBidsByDid.apply(this, arguments);
}
function submitBid(_x9, _x10, _x11, _x12, _x13) {
  return _submitBid.apply(this, arguments);
}
function _submitBid() {
  _submitBid = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee3(collectionId, bid, role, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context3.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          if ((0, _validators.isValidBidRole)(role)) {
            _context3.next = 4;
            break;
          }
          throw new Error('Invalid role');
        case 4:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'submit-bid',
            flags: {
              collection: collectionId,
              value: bid,
              role: role
            }
          };
          _context3.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context3.sent;
          if (response.ok) {
            _context3.next = 12;
            break;
          }
          _context3.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context3.next = 14;
          return response.json();
        case 14:
          data = _context3.sent;
          return _context3.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 16:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _submitBid.apply(this, arguments);
}
function approveBid(_x14, _x15, _x16, _x17, _x18) {
  return _approveBid.apply(this, arguments);
}
function _approveBid() {
  _approveBid = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee4(bidId, collectionId, did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          if ((0, _validators.isValidEventId)(bidId)) {
            _context4.next = 2;
            break;
          }
          throw new Error('Invalid bid ID');
        case 2:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context4.next = 4;
            break;
          }
          throw new Error('Invalid collection ID');
        case 4:
          if ((0, _validators.isValidDid)(did)) {
            _context4.next = 6;
            break;
          }
          throw new Error('Invalid DID');
        case 6:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'evaluate-bid',
            flags: {
              id: bidId,
              collection: collectionId,
              did: did,
              status: 'approved'
            }
          };
          _context4.next = 10;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 10:
          response = _context4.sent;
          if (response.ok) {
            _context4.next = 14;
            break;
          }
          _context4.next = 14;
          return (0, _error.throwResponseError)(response);
        case 14:
          _context4.next = 16;
          return response.json();
        case 16:
          data = _context4.sent;
          return _context4.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 18:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _approveBid.apply(this, arguments);
}
function rejectBid(_x19, _x20, _x21, _x22, _x23, _x24) {
  return _rejectBid.apply(this, arguments);
}
function _rejectBid() {
  _rejectBid = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee5(bidId, collectionId, did, reason, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          if ((0, _validators.isValidEventId)(bidId)) {
            _context5.next = 2;
            break;
          }
          throw new Error('Invalid bid ID');
        case 2:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context5.next = 4;
            break;
          }
          throw new Error('Invalid collection ID');
        case 4:
          if ((0, _validators.isValidDid)(did)) {
            _context5.next = 6;
            break;
          }
          throw new Error('Invalid DID');
        case 6:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'evaluate-bid',
            flags: {
              id: bidId,
              collection: collectionId,
              did: did,
              status: 'rejected',
              data: {
                reason: reason
              }
            }
          };
          _context5.next = 10;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 10:
          response = _context5.sent;
          if (response.ok) {
            _context5.next = 14;
            break;
          }
          _context5.next = 14;
          return (0, _error.throwResponseError)(response);
        case 14:
          _context5.next = 16;
          return response.json();
        case 16:
          data = _context5.sent;
          return _context5.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 18:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
  return _rejectBid.apply(this, arguments);
}
function queryDidIsBlocked(_x25, _x26, _x27, _x28) {
  return _queryDidIsBlocked.apply(this, arguments);
}
function _queryDidIsBlocked() {
  _queryDidIsBlocked = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee6(collectionId, did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee6$(_context6) {
      while (1) switch (_context6.prev = _context6.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context6.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          if ((0, _validators.isValidDid)(did)) {
            _context6.next = 4;
            break;
          }
          throw new Error('Invalid DID');
        case 4:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'did-is-blocked',
            flags: {
              collection: collectionId,
              did: did
            }
          };
          _context6.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context6.sent;
          if (response.ok) {
            _context6.next = 12;
            break;
          }
          _context6.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context6.next = 14;
          return response.json();
        case 14:
          data = _context6.sent;
          return _context6.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 16:
        case "end":
          return _context6.stop();
      }
    }, _callee6);
  }));
  return _queryDidIsBlocked.apply(this, arguments);
}
function didBlock(_x29, _x30, _x31, _x32) {
  return _didBlock.apply(this, arguments);
}
function _didBlock() {
  _didBlock = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee7(collectionId, did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee7$(_context7) {
      while (1) switch (_context7.prev = _context7.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context7.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          if ((0, _validators.isValidDid)(did)) {
            _context7.next = 4;
            break;
          }
          throw new Error('Invalid DID');
        case 4:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'did-block',
            flags: {
              collection: collectionId,
              did: did
            }
          };
          _context7.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context7.sent;
          if (response.ok) {
            _context7.next = 12;
            break;
          }
          _context7.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context7.next = 14;
          return response.json();
        case 14:
          data = _context7.sent;
          return _context7.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 16:
        case "end":
          return _context7.stop();
      }
    }, _callee7);
  }));
  return _didBlock.apply(this, arguments);
}
function didUnblock(_x33, _x34, _x35, _x36) {
  return _didUnblock.apply(this, arguments);
}
function _didUnblock() {
  _didUnblock = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee8(collectionId, did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee8$(_context8) {
      while (1) switch (_context8.prev = _context8.next) {
        case 0:
          if ((0, _validators.isValidCollectionId)(collectionId)) {
            _context8.next = 2;
            break;
          }
          throw new Error('Invalid collection ID');
        case 2:
          if ((0, _validators.isValidDid)(did)) {
            _context8.next = 4;
            break;
          }
          throw new Error('Invalid DID');
        case 4:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'did-unblock',
            flags: {
              collection: collectionId,
              did: did
            }
          };
          _context8.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context8.sent;
          if (response.ok) {
            _context8.next = 12;
            break;
          }
          _context8.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context8.next = 14;
          return response.json();
        case 14:
          data = _context8.sent;
          return _context8.abrupt("return", data === null || data === void 0 ? void 0 : data.data);
        case 16:
        case "end":
          return _context8.stop();
      }
    }, _callee8);
  }));
  return _didUnblock.apply(this, arguments);
}