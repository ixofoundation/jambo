"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.invite = invite;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function invite(_x, _x2, _x3) {
  return _invite.apply(this, arguments);
}
function _invite() {
  _invite = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(roomId, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(botUrl, "/invite");
          payload = {
            roomId: roomId
          };
          _context.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context.sent;
          if (response.ok) {
            _context.next = 10;
            break;
          }
          _context.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context.next = 12;
          return response.json();
        case 12:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 14:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _invite.apply(this, arguments);
}