"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMatrixBidBotClient = createMatrixBidBotClient;
var _1 = _interopRequireWildcard(require("./bid/v1beta1"));
var _2 = _interopRequireWildcard(require("./bot/v1beta1"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { "default": e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n["default"] = e, t && t.set(e, n), n; }
var bidBot;
(function (_bidBot) {
  var bid;
  (function (_bid) {
    var v1beta1 = _bid.v1beta1 = _1;
  })(bid || (bid = _bidBot.bid || (_bidBot.bid = {})));
  var bot;
  (function (_bot) {
    var v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _bidBot.bot || (_bidBot.bot = {})));
})(bidBot || (bidBot = {}));
function createMatrixBidBotClient(_ref) {
  var botUrl = _ref.botUrl,
    accessToken = _ref.accessToken;
  return {
    bid: {
      v1beta1: {
        queryBids: function queryBids(collectionId, pagination, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.queryBids(collectionId, pagination, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        queryBidsByDid: function queryBidsByDid(collectionId, did, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.queryBidsByDid(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        submitBid: function submitBid(collectionId, did, role, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.submitBid(collectionId, did, role, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        approveBid: function approveBid(bidId, collectionId, did, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.approveBid(bidId, collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        rejectBid: function rejectBid(bidId, collectionId, did, reason, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.rejectBid(bidId, collectionId, did, reason, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        queryDidIsBlocked: function queryDidIsBlocked(collectionId, did, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.queryDidIsBlocked(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        didBlock: function didBlock(collectionId, did, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.didBlock(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        didUnblock: function didUnblock(collectionId, did, overrideBotUrl, overrideAccessToken) {
          return bidBot.bid.v1beta1.didUnblock(collectionId, did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        }
      }
    },
    bot: {
      v1beta1: {
        invite: function invite(roomId) {
          return bidBot.bot.v1beta1.invite(roomId, botUrl, accessToken);
        }
      }
    }
  };
}