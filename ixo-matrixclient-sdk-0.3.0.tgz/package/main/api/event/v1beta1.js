"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.queryChildEvents = queryChildEvents;
exports.queryChildEventsByRelType = queryChildEventsByRelType;
exports.queryChildEventsByRelTypeAndEventType = queryChildEventsByRelTypeAndEventType;
exports.queryEvent = queryEvent;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function queryEvent(_x, _x2, _x3, _x4) {
  return _queryEvent.apply(this, arguments);
}
function _queryEvent() {
  _queryEvent = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(roomId, eventId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          console.log('queryEvent', roomId, eventId, homeServerUrl, accessToken);
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context.next = 3;
            break;
          }
          throw new Error('Invalid room ID');
        case 3:
          if ((0, _validators.isValidEventId)(eventId)) {
            _context.next = 5;
            break;
          }
          throw new Error('Invalid event ID');
        case 5:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/rooms/").concat(encodeURIComponent(roomId), "/event/").concat(encodeURIComponent(eventId));
          _context.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 8:
          response = _context.sent;
          if (response.ok) {
            _context.next = 12;
            break;
          }
          _context.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context.next = 14;
          return response.json();
        case 14:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 16:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryEvent.apply(this, arguments);
}
function queryChildEvents(_x5, _x6, _x7, _x8) {
  return _queryChildEvents.apply(this, arguments);
}
function _queryChildEvents() {
  _queryChildEvents = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(roomId, parentEventId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context2.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          if ((0, _validators.isValidEventId)(parentEventId)) {
            _context2.next = 4;
            break;
          }
          throw new Error('Invalid parent event ID');
        case 4:
          url = "".concat(homeServerUrl, "/_matrix/client/v1/rooms/").concat(encodeURIComponent(roomId), "/relations/").concat(encodeURIComponent(parentEventId));
          _context2.next = 7;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 7:
          response = _context2.sent;
          if (response.ok) {
            _context2.next = 11;
            break;
          }
          _context2.next = 11;
          return (0, _error.throwResponseError)(response);
        case 11:
          _context2.next = 13;
          return response.json();
        case 13:
          data = _context2.sent;
          return _context2.abrupt("return", data);
        case 15:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _queryChildEvents.apply(this, arguments);
}
function queryChildEventsByRelType(_x9, _x10, _x11, _x12, _x13) {
  return _queryChildEventsByRelType.apply(this, arguments);
}
function _queryChildEventsByRelType() {
  _queryChildEventsByRelType = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee3(roomId, parentEventId, relType, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context3.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          if ((0, _validators.isValidEventId)(parentEventId)) {
            _context3.next = 4;
            break;
          }
          throw new Error('Invalid parent event ID');
        case 4:
          url = "".concat(homeServerUrl, "/_matrix/client/v1/rooms/").concat(encodeURIComponent(roomId), "/relations/").concat(encodeURIComponent(parentEventId), "/").concat(encodeURIComponent(relType));
          _context3.next = 7;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 7:
          response = _context3.sent;
          if (response.ok) {
            _context3.next = 11;
            break;
          }
          _context3.next = 11;
          return (0, _error.throwResponseError)(response);
        case 11:
          _context3.next = 13;
          return response.json();
        case 13:
          data = _context3.sent;
          return _context3.abrupt("return", data);
        case 15:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _queryChildEventsByRelType.apply(this, arguments);
}
function queryChildEventsByRelTypeAndEventType(_x14, _x15, _x16, _x17, _x18, _x19) {
  return _queryChildEventsByRelTypeAndEventType.apply(this, arguments);
}
function _queryChildEventsByRelTypeAndEventType() {
  _queryChildEventsByRelTypeAndEventType = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee4(roomId, parentEventId, relType, eventType, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context4.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          if ((0, _validators.isValidEventId)(parentEventId)) {
            _context4.next = 4;
            break;
          }
          throw new Error('Invalid parent event ID');
        case 4:
          if ((0, _validators.isValidEventType)(eventType)) {
            _context4.next = 6;
            break;
          }
          throw new Error('Invalid event type');
        case 6:
          url = "".concat(homeServerUrl, "/_matrix/client/v1/rooms/").concat(encodeURIComponent(roomId), "/relations/").concat(encodeURIComponent(parentEventId), "/").concat(encodeURIComponent(relType), "/").concat(encodeURIComponent(eventType));
          _context4.next = 9;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 9:
          response = _context4.sent;
          if (response.ok) {
            _context4.next = 13;
            break;
          }
          _context4.next = 13;
          return (0, _error.throwResponseError)(response);
        case 13:
          _context4.next = 15;
          return response.json();
        case 15:
          data = _context4.sent;
          return _context4.abrupt("return", data);
        case 17:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _queryChildEventsByRelTypeAndEventType.apply(this, arguments);
}