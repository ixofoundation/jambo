"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UploadContentType = void 0;
exports.upload = upload;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _url = require("../../utils/url");
var UploadContentType = exports.UploadContentType = /*#__PURE__*/function (UploadContentType) {
  UploadContentType["PDF"] = "application/pdf";
  UploadContentType["JPEG"] = "image/jpeg";
  UploadContentType["PNG"] = "image/png";
  UploadContentType["GIF"] = "image/gif";
  UploadContentType["BMP"] = "image/bmp";
  UploadContentType["SVG"] = "image/svg+xml";
  UploadContentType["TIFF"] = "image/tiff";
  UploadContentType["WEBP"] = "image/webp";
  UploadContentType["PLAIN_TEXT"] = "text/plain";
  UploadContentType["CSV"] = "text/csv";
  UploadContentType["HTML"] = "text/html";
  UploadContentType["ZIP"] = "application/zip";
  UploadContentType["GZIP"] = "application/gzip";
  UploadContentType["MULTIPART_FORM_DATA"] = "multipart/form-data";
  return UploadContentType;
}({});
function upload(_x, _x2, _x3, _x4, _x5) {
  return _upload.apply(this, arguments);
}
function _upload() {
  _upload = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(filename, type, file, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if (filename) {
            _context.next = 2;
            break;
          }
          throw new Error("'filename' is required to upload content");
        case 2:
          if (type) {
            _context.next = 4;
            break;
          }
          throw new Error("'type' is required to upload content");
        case 4:
          if (file) {
            _context.next = 6;
            break;
          }
          throw new Error("'file' is required to upload content");
        case 6:
          url = "".concat(homeServerUrl, "/_matrix/media/v3/upload");
          url = (0, _url.cleanUrl)(url);
          url += "?filename=".concat(encodeURIComponent(filename));
          _context.next = 11;
          return (0, _nodeFetch["default"])((0, _url.cleanUrl)(url), {
            method: 'POST',
            headers: {
              'Content-Type': type,
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            },
            body: file
          });
        case 11:
          response = _context.sent;
          if (response.ok) {
            _context.next = 15;
            break;
          }
          _context.next = 15;
          return (0, _error.throwResponseError)(response);
        case 15:
          data = response.json();
          return _context.abrupt("return", data);
        case 17:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _upload.apply(this, arguments);
}