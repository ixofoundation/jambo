"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.queryWhoAmI = queryWhoAmI;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
function queryWhoAmI(_x, _x2) {
  return _queryWhoAmI.apply(this, arguments);
}
function _queryWhoAmI() {
  _queryWhoAmI = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if (accessToken) {
            _context.next = 2;
            break;
          }
          throw new Error('AccessToken cannot be empty');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/account/whoami");
          _context.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 5:
          response = _context.sent;
          if (response.ok) {
            _context.next = 9;
            break;
          }
          _context.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context.next = 11;
          return response.json();
        case 11:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 13:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryWhoAmI.apply(this, arguments);
}