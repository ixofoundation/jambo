"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.queryAvatarUrl = queryAvatarUrl;
exports.queryDisplayname = queryDisplayname;
exports.queryProfile = queryProfile;
exports.setAvatarUrl = setAvatarUrl;
exports.setDisplayname = setDisplayname;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function queryProfile(_x, _x2, _x3) {
  return _queryProfile.apply(this, arguments);
}
function _queryProfile() {
  _queryProfile = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(userId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if ((0, _validators.isValidUserId)(userId)) {
            _context.next = 2;
            break;
          }
          throw new Error('Invalid userId');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/profile/").concat(encodeURIComponent(userId));
          _context.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            }
          });
        case 5:
          response = _context.sent;
          if (response.ok) {
            _context.next = 9;
            break;
          }
          _context.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context.next = 11;
          return response.json();
        case 11:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 13:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryProfile.apply(this, arguments);
}
function queryDisplayname(_x4, _x5, _x6) {
  return _queryDisplayname.apply(this, arguments);
}
function _queryDisplayname() {
  _queryDisplayname = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(userId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if ((0, _validators.isValidUserId)(userId)) {
            _context2.next = 2;
            break;
          }
          throw new Error('Invalid userId');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/profile/").concat(encodeURIComponent(userId), "/displayname");
          _context2.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            }
          });
        case 5:
          response = _context2.sent;
          if (response.ok) {
            _context2.next = 9;
            break;
          }
          _context2.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context2.next = 11;
          return response.json();
        case 11:
          data = _context2.sent;
          return _context2.abrupt("return", data.displayname);
        case 13:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _queryDisplayname.apply(this, arguments);
}
function queryAvatarUrl(_x7, _x8, _x9) {
  return _queryAvatarUrl.apply(this, arguments);
}
function _queryAvatarUrl() {
  _queryAvatarUrl = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee3(userId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          if ((0, _validators.isValidUserId)(userId)) {
            _context3.next = 2;
            break;
          }
          throw new Error('Invalid userId');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/profile/").concat(encodeURIComponent(userId), "/avatar_url");
          _context3.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            }
          });
        case 5:
          response = _context3.sent;
          if (response.ok) {
            _context3.next = 9;
            break;
          }
          _context3.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context3.next = 11;
          return response.json();
        case 11:
          data = _context3.sent;
          return _context3.abrupt("return", data.avatar_url);
        case 13:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _queryAvatarUrl.apply(this, arguments);
}
function setDisplayname(_x10, _x11, _x12, _x13) {
  return _setDisplayname.apply(this, arguments);
}
function _setDisplayname() {
  _setDisplayname = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee4(userId, displayname, homeServerUrl, accessToken) {
    var _data$displayname;
    var url, response, data;
    return _regenerator["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          if ((0, _validators.isValidUserId)(userId)) {
            _context4.next = 2;
            break;
          }
          throw new Error('Invalid userId');
        case 2:
          if (displayname) {
            _context4.next = 4;
            break;
          }
          throw new Error('Displayname cannot be empty');
        case 4:
          if (!(typeof displayname !== 'string')) {
            _context4.next = 6;
            break;
          }
          throw new Error('Displayname must be a string');
        case 6:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/profile/").concat(encodeURIComponent(userId), "/displayname");
          _context4.next = 9;
          return (0, _nodeFetch["default"])(url, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify({
              displayname: displayname
            })
          });
        case 9:
          response = _context4.sent;
          if (response.ok) {
            _context4.next = 13;
            break;
          }
          _context4.next = 13;
          return (0, _error.throwResponseError)(response);
        case 13:
          _context4.next = 15;
          return response.json();
        case 15:
          data = _context4.sent;
          return _context4.abrupt("return", (_data$displayname = data.displayname) !== null && _data$displayname !== void 0 ? _data$displayname : displayname);
        case 17:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _setDisplayname.apply(this, arguments);
}
function setAvatarUrl(_x14, _x15, _x16, _x17) {
  return _setAvatarUrl.apply(this, arguments);
}
function _setAvatarUrl() {
  _setAvatarUrl = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee5(userId, avatarUrl, homeServerUrl, accessToken) {
    var _data$avatar_url;
    var url, response, data;
    return _regenerator["default"].wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          if ((0, _validators.isValidUserId)(userId)) {
            _context5.next = 2;
            break;
          }
          throw new Error('Invalid userId');
        case 2:
          if (avatarUrl) {
            _context5.next = 4;
            break;
          }
          throw new Error('Avatar URL cannot be empty');
        case 4:
          if (!(typeof avatarUrl !== 'string')) {
            _context5.next = 6;
            break;
          }
          throw new Error('Avatar URL must be a string');
        case 6:
          if ((0, _validators.isValidMxcLink)(avatarUrl)) {
            _context5.next = 8;
            break;
          }
          throw new Error('Invalid avatar URL');
        case 8:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/profile/").concat(encodeURIComponent(userId), "/avatar_url");
          _context5.next = 11;
          return (0, _nodeFetch["default"])(url, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify({
              avatar_url: avatarUrl
            })
          });
        case 11:
          response = _context5.sent;
          if (response.ok) {
            _context5.next = 15;
            break;
          }
          _context5.next = 15;
          return (0, _error.throwResponseError)(response);
        case 15:
          _context5.next = 17;
          return response.json();
        case 17:
          data = _context5.sent;
          return _context5.abrupt("return", (_data$avatar_url = data.avatar_url) !== null && _data$avatar_url !== void 0 ? _data$avatar_url : avatarUrl);
        case 19:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
  return _setAvatarUrl.apply(this, arguments);
}