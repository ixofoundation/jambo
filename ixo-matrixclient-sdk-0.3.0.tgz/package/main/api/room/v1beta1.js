"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.join = join;
exports.kick = kick;
exports.knock = knock;
exports.leave = leave;
exports.listJoinedMembers = listJoinedMembers;
exports.listJoinedRooms = listJoinedRooms;
exports.queryId = queryId;
exports.queryVisibility = queryVisibility;
exports.setVisibility = setVisibility;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function queryId(_x, _x2, _x3) {
  return _queryId.apply(this, arguments);
}
function _queryId() {
  _queryId = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(alias, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if ((0, _validators.isValidRoomAlias)(alias)) {
            _context.next = 2;
            break;
          }
          throw new Error('Invalid room alias');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/directory/room/").concat(encodeURIComponent(alias));
          _context.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            }
          });
        case 5:
          response = _context.sent;
          if (response.ok) {
            _context.next = 9;
            break;
          }
          _context.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context.next = 11;
          return response.json();
        case 11:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 13:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryId.apply(this, arguments);
}
function queryVisibility(_x4, _x5, _x6) {
  return _queryVisibility.apply(this, arguments);
}
function _queryVisibility() {
  _queryVisibility = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(roomId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context2.next = 2;
            break;
          }
          throw new Error('Invalid roomId');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/directory/list/room/").concat(encodeURIComponent(roomId));
          _context2.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            }
          });
        case 5:
          response = _context2.sent;
          if (response.ok) {
            _context2.next = 9;
            break;
          }
          _context2.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context2.next = 11;
          return response.json();
        case 11:
          data = _context2.sent;
          return _context2.abrupt("return", data);
        case 13:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _queryVisibility.apply(this, arguments);
}
function setVisibility(_x7, _x8, _x9, _x10) {
  return _setVisibility.apply(this, arguments);
}
function _setVisibility() {
  _setVisibility = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee3(roomId, visibility, homeServerUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context3.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/directory/list/room/").concat(encodeURIComponent(roomId));
          payload = {
            visibility: visibility
          };
          _context3.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context3.sent;
          if (response.ok) {
            _context3.next = 10;
            break;
          }
          _context3.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context3.next = 12;
          return response.json();
        case 12:
          data = _context3.sent;
          return _context3.abrupt("return", data);
        case 14:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _setVisibility.apply(this, arguments);
}
function knock(_x11, _x12, _x13) {
  return _knock.apply(this, arguments);
}
function _knock() {
  _knock = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee4(roomIdOrAlias, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomIdOrAlias)) {
            _context4.next = 2;
            break;
          }
          throw new Error('Invalid room ID or alias');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/knock/").concat(encodeURIComponent(roomIdOrAlias));
          _context4.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 5:
          response = _context4.sent;
          if (response.ok) {
            _context4.next = 9;
            break;
          }
          _context4.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context4.next = 11;
          return response.json();
        case 11:
          data = _context4.sent;
          return _context4.abrupt("return", data);
        case 13:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _knock.apply(this, arguments);
}
function join(_x14, _x15, _x16) {
  return _join.apply(this, arguments);
}
function _join() {
  _join = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee5(roomIdOrAlias, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomIdOrAlias)) {
            _context5.next = 2;
            break;
          }
          throw new Error('Invalid room ID or alias');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/join/").concat(encodeURIComponent(roomIdOrAlias));
          _context5.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 5:
          response = _context5.sent;
          if (response.ok) {
            _context5.next = 9;
            break;
          }
          _context5.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context5.next = 11;
          return response.json();
        case 11:
          data = _context5.sent;
          return _context5.abrupt("return", data);
        case 13:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
  return _join.apply(this, arguments);
}
function listJoinedRooms(_x17, _x18) {
  return _listJoinedRooms.apply(this, arguments);
}
function _listJoinedRooms() {
  _listJoinedRooms = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee6(homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee6$(_context6) {
      while (1) switch (_context6.prev = _context6.next) {
        case 0:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/joined_rooms");
          _context6.next = 3;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 3:
          response = _context6.sent;
          if (response.ok) {
            _context6.next = 7;
            break;
          }
          _context6.next = 7;
          return (0, _error.throwResponseError)(response);
        case 7:
          _context6.next = 9;
          return response.json();
        case 9:
          data = _context6.sent;
          return _context6.abrupt("return", data);
        case 11:
        case "end":
          return _context6.stop();
      }
    }, _callee6);
  }));
  return _listJoinedRooms.apply(this, arguments);
}
function listJoinedMembers(_x19, _x20, _x21) {
  return _listJoinedMembers.apply(this, arguments);
}
function _listJoinedMembers() {
  _listJoinedMembers = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee7(roomId, homeServerUrl, accessToken) {
    var url, response, data;
    return _regenerator["default"].wrap(function _callee7$(_context7) {
      while (1) switch (_context7.prev = _context7.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context7.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/rooms/").concat(encodeURIComponent(roomId), "/joined_members");
          _context7.next = 5;
          return (0, _nodeFetch["default"])(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            }
          });
        case 5:
          response = _context7.sent;
          if (response.ok) {
            _context7.next = 9;
            break;
          }
          _context7.next = 9;
          return (0, _error.throwResponseError)(response);
        case 9:
          _context7.next = 11;
          return response.json();
        case 11:
          data = _context7.sent;
          return _context7.abrupt("return", data);
        case 13:
        case "end":
          return _context7.stop();
      }
    }, _callee7);
  }));
  return _listJoinedMembers.apply(this, arguments);
}
function leave(_x22, _x23, _x24, _x25) {
  return _leave.apply(this, arguments);
}
function _leave() {
  _leave = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee8(roomId, reason, homeServerUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee8$(_context8) {
      while (1) switch (_context8.prev = _context8.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context8.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/rooms/").concat(encodeURIComponent(roomId), "/leave");
          payload = {
            reason: reason
          };
          _context8.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context8.sent;
          if (response.ok) {
            _context8.next = 10;
            break;
          }
          _context8.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context8.next = 12;
          return response.json();
        case 12:
          data = _context8.sent;
          return _context8.abrupt("return", data);
        case 14:
        case "end":
          return _context8.stop();
      }
    }, _callee8);
  }));
  return _leave.apply(this, arguments);
}
function kick(_x26, _x27, _x28, _x29, _x30) {
  return _kick.apply(this, arguments);
}
function _kick() {
  _kick = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee9(roomId, userId, reason, homeServerUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee9$(_context9) {
      while (1) switch (_context9.prev = _context9.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context9.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          if ((0, _validators.isValidUserId)(userId)) {
            _context9.next = 4;
            break;
          }
          throw new Error('Invalid user ID');
        case 4:
          url = "".concat(homeServerUrl, "/_matrix/client/v3/rooms/").concat(encodeURIComponent(roomId), "/kick");
          payload = {
            user_id: userId,
            reason: reason
          };
          _context9.next = 8;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 8:
          response = _context9.sent;
          if (response.ok) {
            _context9.next = 12;
            break;
          }
          _context9.next = 12;
          return (0, _error.throwResponseError)(response);
        case 12:
          _context9.next = 14;
          return response.json();
        case 14:
          data = _context9.sent;
          return _context9.abrupt("return", data);
        case 16:
        case "end":
          return _context9.stop();
      }
    }, _callee9);
  }));
  return _kick.apply(this, arguments);
}