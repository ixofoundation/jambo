"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMatrixApiClient = createMatrixApiClient;
var _1 = _interopRequireWildcard(require("./media/v1beta1"));
var _2 = _interopRequireWildcard(require("./profile/v1beta1"));
var _3 = _interopRequireWildcard(require("./room/v1beta1"));
var _4 = _interopRequireWildcard(require("./account/v1beta1"));
var _5 = _interopRequireWildcard(require("./event/v1beta1"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { "default": e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n["default"] = e, t && t.set(e, n), n; }
var api;
(function (_api) {
  var media;
  (function (_media) {
    var v1beta1 = _media.v1beta1 = _1;
  })(media || (media = _api.media || (_api.media = {})));
  var profile;
  (function (_profile) {
    var v1beta1 = _profile.v1beta1 = _2;
  })(profile || (profile = _api.profile || (_api.profile = {})));
  var room;
  (function (_room) {
    var v1beta1 = _room.v1beta1 = _3;
  })(room || (room = _api.room || (_api.room = {})));
  var account;
  (function (_account) {
    var v1beta1 = _account.v1beta1 = _4;
  })(account || (account = _api.account || (_api.account = {})));
  var event;
  (function (_event) {
    var v1beta1 = _event.v1beta1 = _5;
  })(event || (event = _api.event || (_api.event = {})));
})(api || (api = {}));
function createMatrixApiClient(_ref) {
  var homeServerUrl = _ref.homeServerUrl,
    accessToken = _ref.accessToken;
  return {
    media: {
      v1beta1: {
        upload: function upload(filename, type, file, overrideHomeServerUrl, overrideAccessToken) {
          return api.media.v1beta1.upload(filename, type, file, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        }
      }
    },
    profile: {
      v1beta1: {
        queryProfile: function queryProfile(userId, overrideHomeServerUrl, overrideAccessToken) {
          return api.profile.v1beta1.queryProfile(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryDisplayname: function queryDisplayname(userId, overrideHomeServerUrl, overrideAccessToken) {
          return api.profile.v1beta1.queryDisplayname(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryAvatarUrl: function queryAvatarUrl(userId, overrideHomeServerUrl, overrideAccessToken) {
          return api.profile.v1beta1.queryAvatarUrl(userId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        setDisplayname: function setDisplayname(userId, displayname, overrideHomeServerUrl, overrideAccessToken) {
          return api.profile.v1beta1.setDisplayname(userId, displayname, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        setAvatarUrl: function setAvatarUrl(userId, avatarUrl, overrideHomeServerUrl, overrideAccessToken) {
          return api.profile.v1beta1.setAvatarUrl(userId, avatarUrl, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        }
      }
    },
    account: {
      v1beta1: {
        queryWhoAmI: function queryWhoAmI(overrideHomeServerUrl, overrideAccessToken) {
          return api.account.v1beta1.queryWhoAmI(overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        }
      }
    },
    room: {
      v1beta1: {
        queryId: function queryId(alias, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.queryId(alias, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryVisibility: function queryVisibility(roomId, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.queryVisibility(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        setVisibility: function setVisibility(roomId, visibility, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.setVisibility(roomId, visibility, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        knock: function knock(roomIdOrAlias, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.knock(roomIdOrAlias, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        join: function join(roomId, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.join(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        listJoinedRooms: function listJoinedRooms(overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.listJoinedRooms(overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        listJoinedMembers: function listJoinedMembers(roomId, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.listJoinedMembers(roomId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        leave: function leave(roomId, reason, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.leave(roomId, reason, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        kick: function kick(roomId, userId, reason, overrideHomeServerUrl, overrideAccessToken) {
          return api.room.v1beta1.kick(roomId, userId, reason, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        }
      }
    },
    event: {
      v1beta1: {
        queryEvent: function queryEvent(roomId, eventId, overrideHomeServerUrl, overrideAccessToken) {
          return api.event.v1beta1.queryEvent(roomId, eventId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryChildEvents: function queryChildEvents(roomId, parentEventId, overrideHomeServerUrl, overrideAccessToken) {
          return api.event.v1beta1.queryChildEvents(roomId, parentEventId, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryChildEventsByRelType: function queryChildEventsByRelType(roomId, parentEventId, relType, overrideHomeServerUrl, overrideAccessToken) {
          return api.event.v1beta1.queryChildEventsByRelType(roomId, parentEventId, relType, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        },
        queryChildEventsByRelTypeAndEventType: function queryChildEventsByRelTypeAndEventType(roomId, parentEventId, relType, eventType, overrideHomeServerUrl, overrideAccessToken) {
          return api.event.v1beta1.queryChildEventsByRelTypeAndEventType(roomId, parentEventId, relType, eventType, overrideHomeServerUrl || homeServerUrl, overrideAccessToken || accessToken);
        }
      }
    }
  };
}