"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMatrixRoomBotClient = createMatrixRoomBotClient;
var _1 = _interopRequireWildcard(require("./room/v1beta1"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { "default": e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n["default"] = e, t && t.set(e, n), n; }
var roomBot;
(function (_roomBot) {
  var room;
  (function (_room) {
    var v1beta1 = _room.v1beta1 = _1;
  })(room || (room = _roomBot.room || (_roomBot.room = {})));
})(roomBot || (roomBot = {}));
function createMatrixRoomBotClient(_ref) {
  var homeServerUrl = _ref.homeServerUrl,
    botUrl = _ref.botUrl,
    accessToken = _ref.accessToken;
  return {
    room: {
      v1beta1: {
        sourceRoom: function sourceRoom(did, overrideBotUrl, overrideAccessToken) {
          return roomBot.room.v1beta1.sourceRoom(did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        sourceRoomAndJoin: function sourceRoomAndJoin(did, overrideHomeServerUrl, overrideBotUrl, overrideAccessToken) {
          return roomBot.room.v1beta1.sourceRoomAndJoin(did, overrideHomeServerUrl || homeServerUrl, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        roomInvite: function roomInvite(did, overrideBotUrl, overrideAccessToken) {
          return roomBot.room.v1beta1.roomInvite(did, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        roomInviteAndJoin: function roomInviteAndJoin(did, overrideHomeServerUrl, overrideBotUrl, overrideAccessToken) {
          return roomBot.room.v1beta1.roomInviteAndJoin(did, overrideHomeServerUrl || homeServerUrl, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        }
      }
    }
  };
}