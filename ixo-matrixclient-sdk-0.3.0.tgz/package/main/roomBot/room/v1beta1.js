"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.roomInvite = roomInvite;
exports.roomInviteAndJoin = roomInviteAndJoin;
exports.sourceRoom = sourceRoom;
exports.sourceRoomAndJoin = sourceRoomAndJoin;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _v1beta = require("../../api/room/v1beta1");
// WIll only create room if not exists yet
function sourceRoom(_x, _x2, _x3) {
  return _sourceRoom.apply(this, arguments);
}
function _sourceRoom() {
  _sourceRoom = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          url = "".concat(botUrl, "/room/source");
          payload = {
            did: did
          };
          _context.next = 4;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            },
            body: JSON.stringify(payload)
          });
        case 4:
          response = _context.sent;
          if (response.ok) {
            _context.next = 8;
            break;
          }
          _context.next = 8;
          return (0, _error.throwResponseError)(response);
        case 8:
          _context.next = 10;
          return response.json();
        case 10:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 12:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _sourceRoom.apply(this, arguments);
}
function sourceRoomAndJoin(_x4, _x5, _x6, _x7) {
  return _sourceRoomAndJoin.apply(this, arguments);
}
function _sourceRoomAndJoin() {
  _sourceRoomAndJoin = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(did, homeServerUrl, botUrl, accessToken) {
    var createRoomResponse, roomId, joinRoomResponse;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return sourceRoom(did, botUrl, accessToken);
        case 2:
          createRoomResponse = _context2.sent;
          console.log('createRoomResponse', createRoomResponse);
          if (createRoomResponse.roomId) {
            _context2.next = 6;
            break;
          }
          throw new Error('Room ID not found');
        case 6:
          roomId = createRoomResponse.roomId;
          _context2.next = 9;
          return (0, _v1beta.join)(roomId, homeServerUrl, accessToken);
        case 9:
          joinRoomResponse = _context2.sent;
          if (joinRoomResponse.room_id) {
            _context2.next = 12;
            break;
          }
          throw new Error('Failed to join created room');
        case 12:
          if (!(joinRoomResponse.room_id !== roomId)) {
            _context2.next = 14;
            break;
          }
          throw new Error('Joined room ID does not match created room ID');
        case 14:
          return _context2.abrupt("return", createRoomResponse);
        case 15:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _sourceRoomAndJoin.apply(this, arguments);
}
function roomInvite(_x8, _x9, _x10) {
  return _roomInvite.apply(this, arguments);
}
function _roomInvite() {
  _roomInvite = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee3(did, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          url = "".concat(botUrl, "/room/invite");
          payload = {
            did: did
          };
          _context3.next = 4;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: "Bearer ".concat(accessToken)
            },
            body: JSON.stringify(payload)
          });
        case 4:
          response = _context3.sent;
          if (response.ok) {
            _context3.next = 8;
            break;
          }
          _context3.next = 8;
          return (0, _error.throwResponseError)(response);
        case 8:
          _context3.next = 10;
          return response.json();
        case 10:
          data = _context3.sent;
          return _context3.abrupt("return", data);
        case 12:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _roomInvite.apply(this, arguments);
}
function roomInviteAndJoin(_x11, _x12, _x13, _x14) {
  return _roomInviteAndJoin.apply(this, arguments);
}
function _roomInviteAndJoin() {
  _roomInviteAndJoin = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee4(did, homeServerUrl, botUrl, accessToken) {
    var roomInviteResponse, roomId, joinRoomResponse;
    return _regenerator["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          _context4.next = 2;
          return roomInvite(did, botUrl, accessToken);
        case 2:
          roomInviteResponse = _context4.sent;
          if (roomInviteResponse.roomId) {
            _context4.next = 5;
            break;
          }
          throw new Error('Room ID not found');
        case 5:
          roomId = roomInviteResponse.roomId;
          _context4.next = 8;
          return (0, _v1beta.join)(roomId, homeServerUrl, accessToken);
        case 8:
          joinRoomResponse = _context4.sent;
          if (joinRoomResponse.room_id) {
            _context4.next = 11;
            break;
          }
          throw new Error('Failed to join room invite');
        case 11:
          if (!(joinRoomResponse.room_id !== roomId)) {
            _context4.next = 13;
            break;
          }
          throw new Error('Joined room ID does not invited room ID');
        case 13:
          return _context4.abrupt("return", roomInviteResponse);
        case 14:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _roomInviteAndJoin.apply(this, arguments);
}