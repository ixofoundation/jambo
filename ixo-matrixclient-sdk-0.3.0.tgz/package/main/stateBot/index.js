"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMatrixStateBotClient = createMatrixStateBotClient;
var _1 = _interopRequireWildcard(require("./acl/v1beta1"));
var _2 = _interopRequireWildcard(require("./bot/v1beta1"));
var _3 = _interopRequireWildcard(require("./state/v1beta1"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { "default": e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n["default"] = e, t && t.set(e, n), n; }
var stateBot;
(function (_stateBot) {
  var acl;
  (function (_acl) {
    var v1beta1 = _acl.v1beta1 = _1;
  })(acl || (acl = _stateBot.acl || (_stateBot.acl = {})));
  var bot;
  (function (_bot) {
    var v1beta1 = _bot.v1beta1 = _2;
  })(bot || (bot = _stateBot.bot || (_stateBot.bot = {})));
  var state;
  (function (_state) {
    var v1beta1 = _state.v1beta1 = _3;
  })(state || (state = _stateBot.state || (_stateBot.state = {})));
})(stateBot || (stateBot = {}));
function createMatrixStateBotClient(_ref) {
  var botUrl = _ref.botUrl,
    accessToken = _ref.accessToken;
  return {
    acl: {
      v1beta1: {
        queryAcl: function queryAcl(roomId, key, path, overrideBotUrl, overrideAccessToken) {
          return stateBot.acl.v1beta1.queryAcl(roomId, key, path, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        setAcl: function setAcl(roomId, key, path, value, overrideBotUrl, overrideAccessToken) {
          return stateBot.acl.v1beta1.setAcl(roomId, key, path, value, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        }
      }
    },
    bot: {
      v1beta1: {
        invite: function invite(roomId, overrideBotUrl, overrideAccessToken) {
          return stateBot.bot.v1beta1.invite(roomId, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        }
      }
    },
    state: {
      v1beta1: {
        queryState: function queryState(roomId, key, path, overrideBotUrl, overrideAccessToken) {
          return stateBot.state.v1beta1.queryState(roomId, key, path, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        },
        setState: function setState(roomId, key, path, value, overrideBotUrl, overrideAccessToken) {
          return stateBot.state.v1beta1.setState(roomId, key, path, value, overrideBotUrl || botUrl, overrideAccessToken || accessToken);
        }
      }
    }
  };
}