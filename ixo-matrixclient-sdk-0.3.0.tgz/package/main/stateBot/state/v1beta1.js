"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.queryState = queryState;
exports.setState = setState;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
var _error = require("../../utils/error");
var _validators = require("../../utils/validators");
function queryState(_x, _x2, _x3, _x4, _x5) {
  return _queryState.apply(this, arguments);
}
function _queryState() {
  _queryState = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(roomId, key, path, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'get',
            roomId: roomId,
            flags: {
              key: key || '',
              path: path || '/'
            }
          };
          _context.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context.sent;
          if (response.ok) {
            _context.next = 10;
            break;
          }
          _context.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context.next = 12;
          return response.json();
        case 12:
          data = _context.sent;
          return _context.abrupt("return", data);
        case 14:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _queryState.apply(this, arguments);
}
function setState(_x6, _x7, _x8, _x9, _x10, _x11) {
  return _setState.apply(this, arguments);
}
function _setState() {
  _setState = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(roomId, key, path, value, botUrl, accessToken) {
    var url, payload, response, data;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if ((0, _validators.isValidRoomId)(roomId)) {
            _context2.next = 2;
            break;
          }
          throw new Error('Invalid room ID');
        case 2:
          url = "".concat(botUrl, "/action");
          payload = {
            action: 'set',
            roomId: roomId,
            flags: {
              key: key || '',
              path: path || '/',
              value: value
            }
          };
          _context2.next = 6;
          return (0, _nodeFetch["default"])(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: accessToken ? "Bearer ".concat(accessToken) : undefined
            },
            body: JSON.stringify(payload)
          });
        case 6:
          response = _context2.sent;
          if (response.ok) {
            _context2.next = 10;
            break;
          }
          _context2.next = 10;
          return (0, _error.throwResponseError)(response);
        case 10:
          _context2.next = 12;
          return response.json();
        case 12:
          data = _context2.sent;
          return _context2.abrupt("return", data);
        case 14:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _setState.apply(this, arguments);
}